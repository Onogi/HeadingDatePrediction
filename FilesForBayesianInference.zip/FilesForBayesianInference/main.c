#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "mkdir.h"
#include "header.h"

/* Program to predict heading dates using the DVR model

	Assumption on the DVR model parameters
	1: g ~ MVN (Mug, I x Sigmag) where I is the identity matrix.
	2: g ~ MVN (Mug, G x Sigmag) where G is the relationship matrix among lines. G^-1 is input using the parameter InverseRMfile.
	3: g = f(X) + e where X is the marker genotypes. The regression is performed using variational Bayesian inference or EM algorithms.
	4: g = g(X) + e. A kernel regression is performed using MCMC.
	The same assumption is applied to alpha (a) and beta (beta) of the DVR model.

	Methodcode which defines f(X)
	1: BL (Bayesian lasso)
	2: EBL (extended Bayesian lasso)
	3: wBSR (weighted Bayesian shrinkage regression)
	4: BayesC
	5: SSVS (Stochastic search variable selection)
	6: MIX (Baysian mixture models)
	The details of the regression methods are described in the pdf manual of VIGoR (https://github.com/Onogi/VIGoR)

	Algorithm applied to f(X)
	1: VB (variational Bayesian inference)
	2: EM (EM algorithm. This may not work)

	About Log transformation
	*When Assumption = 1 or 2, and Logtransfromation = 0, trancated multivariate normal distributions are used as the prior distributions of g, a, and b.
	 The means and variances of the prior distributions are not inferred and fixed to IniMug and IniSigmag, respectively, in the case of g.
	*When Assumption = 1 or 2, and Logtransformation = 1, multivariate normal distributions are used and the means and variances are inferred.
	*When Assumption = 3 or 4, Logtransformation should be 1.

*/
int main (int argc, char *argv[]) 
{

	/* parameters read from the parameter file */
	char	FolderName[101]="";				/* Name of the folder in which the result files are output */
	char	AnalysisName[101]="";			/* Name of the analysis. This is used in the output file names */
	char	Emergencefile[101]="";			/* Emergence date file name */ 
	char	Headingfile[101]="";			/* Heading date file name */
	char	DailyTempfile[101]="";			/* Daily mean temperature file name */
	char	Photoperiodfile[101]="";		/* Photoperiod file name */
	int		Assumption;						/* Model assumption name */
	int		Methodcode;						/* This parameter specifies the regression method used. Used only when Assumption = 3 */
	int		Algorithm;						/* Algorithm to infer the regression coefficients. Used when Assumption = 3 */
	char	InverseRMfile[101]="";			/* Inverse relationship matrix file. Used when Assumption = 2 or 4 */
	char	Genotypefile[101]="";			/* Marker genotype file. Used only when Assumption = 3 */
	int		Logtransform;					/* Perform log transformation (1) or not (0) */
	int		Nl;								/* Number of lines */
	int		Ne;								/* Number of environments */
	int		Md;								/* Maximum number of days in Dailytempfile and Photoperiodfile */
	int		Missing;						/* Missing values in input files */
	int		P;								/* Number of markers included in the Genotypefile */
	double	IniMug;							/* If Assumption = 1 or 2 and Logtransform = 0, IniMug is used as the mean of the prior distributions of g. Otherwise, this is used as the initial value */
	double	IniSigmag;						/* If Assumption = 1 or 2 and Logtransform = 0, IniSigmag is used as the variance of the prior distributions of g. Otherwise, this is used as the initial value */
	double	IniMua;
	double	IniSigmaa;
	double	IniMub;
	double	IniSigmab;
	double	Sdforg;							/* SD of the proposal normal distribution of alpha */
	double	Sdfora;
	double	Sdforb;
	double	Sdforve;						/* SD of the proposal normal distribution for the residual variance */
	double	Xi1g;							/* This is used for standardization of g when Assumption = 3 */
	double	Xi2g;
	double	Xi1a;
	double	Xi2a;
	double	Xi1b;
	double	Xi2b;
	int     Burnin;							/* Length of burnin */
	int     Ite;							/* Length of iterations after burnin. When Assumption = 3, this is the number of iterations at the last MCMC-VB/EM loop. Before the last loop, Ite/5 is used. */
	int     Thi;							/* Frequency of sampling */
	int		Nloops;							/* Maximum number of MCMC-VB/EM loops */
	int		Niterations;					/* Maximum number of the iterations of VB/EM in a loop */
	char	PartitionEnvfile[101]="";		/* Partition file name for cross-validation over environments. Input 0 if it is not performed */
	char	PartitionLinefile[101]="";		/* Partition file name for cross-validation over lines. Input 0 if it is not performed*/

	/* ===== Important ===========================================================================================================
	When Assumption = 3, hyperparameters of the regression method should be specified at the last two rows of the parameter file.
	When the regression method is EBL, an example of the last four rows of the parameter file is

		PartitionEnvfile 8env.txt
		PartitionLinefile 0
		Hyperparameters
		0.1 0.1 1 0.1

	This indicates that the four hyperparameters of the EBL regression is 0.1, 0.1, 1, and 0.1.
	The details of the hyperparameters are described of the pdf manual of VIGoR (https://github.com/Onogi/VIGoR)
	================================================================================================================================*/

	/* Seed used */
	int		usedseed;

	/* Inputs and outputs */
	char    File[101]="";
	char	Readline[] = {'\0'};
	FILE    *fp, *fp2;

	/* MCMC iteration */
	int		Totalite;

	/* For repeat statement */
	int		ii;
	int		line, env, day, record, locus, para;

	/* temporary use */
	double	TempDouble;
	int		TempInt;

	/* Daily temp and photoperiod */
	Environment	*Temp, *Photo;

	/* Line information */
	Cultivar	*Line, *LineCv, *LineCv2;

	/* Transformation of Temp and Photo */
	double	TcTo, ToTb, Tratio;
	double	PcPo, PoPb, Pratio;

	/* Sampling */
	int		Ns, Nswb;
	double *Loglike; 
	double	SampledSigmag[2], SampledSigmaa[2], SampledSigmab[2], SampledVe[2];
	double	SampledPolySigmag[2], SampledPolySigmaa[2], SampledPolySigmab[2];
	double	SampledMug[2], SampledMua[2], SampledMub[2];

	/* Acceptance rate */
	int Acg, Aca, Acb, Acve;

	/* Predicted values*/
	Matrix	*PredictedDH;

	/* Inverse relationship matrix */
	Matrix	*Gmatrix;
	int	row, col;

	/* Cross-validation */
	int	CVline, FoldLine, MaxntestLine, foldline;
	Pstruct	*PLine;
	int	CVenv, FoldEnv, MaxntestEnv, foldenv;
	Pstruct *PEnv;

	/* When regression */
	Xstruct *X, *Q, *Xg, *Xa, *Xb, *Qg, *Qa, *Qb;
	Ystruct *Y;
	Hstruct *H;
	int		Nn, Nset=1;

	/* Pre-determined values */
	double Tb=8.0, Tc=42.0, To=30.0, Pb=0.0, Pc=24.0, Po=10.0;


	/* Open the parameter file */
	if ( ( fp = fopen( argv[1], "r" ) ) == NULL )
	{
	   	printf("Error: cannot open the parameter file\n" );
		return (0);
	}

	/* Read the parameter file */
	fscanf (fp, "%*s%s", FolderName);
	fscanf (fp, "%*s%s", AnalysisName);
	fscanf (fp, "%*s%s", Emergencefile);
	fscanf (fp, "%*s%s", Headingfile);
	fscanf (fp, "%*s%s", DailyTempfile);
	fscanf (fp, "%*s%s", Photoperiodfile);
	fscanf (fp, "%*s%d", &Assumption);
	fscanf (fp, "%*s%d", &Methodcode);
	fscanf (fp, "%*s%d", &Algorithm);

		if(Assumption==1||Assumption==2||Assumption==4) {Methodcode=0; Algorithm=0;}

	fscanf (fp, "%*s%s", InverseRMfile);
	fscanf (fp, "%*s%s", Genotypefile);
	fscanf (fp, "%*s%d", &Logtransform);

		if((Assumption==3||Assumption==4)&&Logtransform==0) {printf("Logtransform should be 1\n"); return(0);}

	fscanf (fp, "%*s%d", &Nl);
	fscanf (fp, "%*s%d", &Ne);
	fscanf (fp, "%*s%d", &Md);
	fscanf (fp, "%*s%d", &Missing);
	fscanf (fp, "%*s%d", &P);

	fscanf (fp, "%*s%lf", &IniMug);
	fscanf (fp, "%*s%lf", &IniSigmag);
	fscanf (fp, "%*s%lf", &IniMua);
	fscanf (fp, "%*s%lf", &IniSigmaa);
	fscanf (fp, "%*s%lf", &IniMub);
	fscanf (fp, "%*s%lf", &IniSigmab);

	fscanf (fp, "%*s%lf", &Sdforg);
	fscanf (fp, "%*s%lf", &Sdfora);
	fscanf (fp, "%*s%lf", &Sdforb);
	fscanf (fp, "%*s%lf", &Sdforve);

	fscanf (fp, "%*s%lf", &Xi1g );
	fscanf (fp, "%*s%lf", &Xi2g );
	fscanf (fp, "%*s%lf", &Xi1a );
	fscanf (fp, "%*s%lf", &Xi2a );
	fscanf (fp, "%*s%lf", &Xi1b );
	fscanf (fp, "%*s%lf", &Xi2b );

	fscanf (fp, "%*s%d", &Burnin);
	fscanf (fp, "%*s%d", &Ite);
	fscanf (fp, "%*s%d", &Thi);
	fscanf (fp, "%*s%d", &Nloops);
	fscanf (fp, "%*s%d", &Niterations);
	fscanf (fp, "%*s%s", PartitionEnvfile);

		if(PartitionEnvfile[0]=='0') CVenv=0; else CVenv=1;

	fscanf (fp, "%*s%s", PartitionLinefile);
	
		if(PartitionLinefile[0]=='0') CVline=0; else CVline=1;

	if(Assumption==3)
	{
		fscanf (fp, "%*s"); /* skip one row */
		H = (Hstruct*) calloc (Nset, sizeof(Hstruct));
		switch(Methodcode){
			case 1:	/*BL*/
				fscanf(fp, "%lf %lf", &(H[0].deltaShape), &(H[0].deltaRate));
				break;
			case 2: /*EBL*/
				fscanf(fp, "%lf %lf %lf %lf", &(H[0].deltaShape), &(H[0].deltaRate), &(H[0].etaShape), &(H[0].etaRate));
				break;
			case 3: /*wBSR*/
				fscanf(fp, "%lf %lf %lf", &(H[0].v), &(H[0].S2), &(H[0].Pi));
				break;
			case 4: /*BayesC*/
				fscanf(fp, "%lf %lf %lf", &(H[0].v), &(H[0].S2), &(H[0].Pi));
				break;
			case 5: /*SSVS*/
				fscanf(fp, "%lf %lf %lf %lf", &(H[0].c), &(H[0].v), &(H[0].S2), &(H[0].Pi));
				break;
			case 6: /*MIX*/
				fscanf(fp, "%lf %lf %lf %lf", &(H[0].c), &(H[0].v), &(H[0].S2), &(H[0].Pi));
				break;
		}
	}
	fclose (fp);

	/* Initialize the seed */
	usedseed = Randomize ( seed );
	putchar ( '\n' );
	printf ( "Random seed: %d\n", usedseed );
	putchar ( '\n' );
	ix = ( rand()%30000 ) + 1;
	iy = ( rand()%30000 ) + 1;
	iz = ( rand()%30000 ) + 1;

	/* Create a new directory for results */
	MKDIR(FolderName);

	/* Output the parameters */
	sprintf ( File, "./%s/%s_parameters.txt", FolderName, AnalysisName );
	fp = fopen ( File, "w" );
	fprintf ( fp, "Emergencefile       : %s\n", Emergencefile );
	fprintf ( fp, "Headingfile         : %s\n", Headingfile );
	fprintf ( fp, "DailyTempfile       : %s\n", DailyTempfile );
	fprintf ( fp, "Photoperiodfile     : %s\n", Photoperiodfile );
	fprintf ( fp, "Assumption          : %d\n", Assumption ); 
	fprintf ( fp, "Methodcode          : %d\n", Methodcode );
	fprintf ( fp, "Algorithm           : %d\n", Algorithm );
	fprintf ( fp, "InverseRMfile       : %s\n", InverseRMfile );
	fprintf ( fp, "Genotypefile        : %s\n", Genotypefile );
	fprintf ( fp, "Logtransform        : %d\n", Logtransform );

	fprintf ( fp, "Nl                  : %d\n", Nl );
	fprintf ( fp, "Ne                  : %d\n", Ne );
	fprintf ( fp, "Md                  : %d\n", Md );
	fprintf ( fp, "Missing             : %d\n", Missing );
	fprintf ( fp, "P                   : %d\n", P );

	fprintf ( fp, "IniMug              : %f\n", IniMug );
	fprintf ( fp, "IniSigmag           : %f\n", IniSigmag );
	fprintf ( fp, "IniMua              : %f\n", IniMua );
	fprintf ( fp, "IniSigmaa           : %f\n", IniSigmaa );
	fprintf ( fp, "IniMub              : %f\n", IniMub );
	fprintf ( fp, "IniSigmab           : %f\n", IniSigmab );

	fprintf ( fp, "Sdforg              : %f\n", Sdforg );
	fprintf ( fp, "Sdfora              : %f\n", Sdfora );
	fprintf ( fp, "Sdforb              : %f\n", Sdforb );
	fprintf ( fp, "Sdforve             : %f\n", Sdforve );

	fprintf ( fp, "Xi1g                : %f\n", Xi1g );
	fprintf ( fp, "Xi2g                : %f\n", Xi2g );
	fprintf ( fp, "Xi1a                : %f\n", Xi1a );
	fprintf ( fp, "Xi2a                : %f\n", Xi2a );
	fprintf ( fp, "Xi1b                : %f\n", Xi1b );
	fprintf ( fp, "Xi2b                : %f\n", Xi2b );

	fprintf ( fp, "Burnin              : %d\n", Burnin);
	fprintf ( fp, "Ite                 : %d\n", Ite);
	fprintf ( fp, "Thi                 : %d\n", Thi);
	fprintf ( fp, "Nloops              : %d\n", Nloops);
	fprintf ( fp, "Niterations         : %d\n", Niterations);
	fprintf ( fp, "PartitionEnvfile    : %s\n", PartitionEnvfile);
	fprintf ( fp, "PartitionLinefile   : %s\n", PartitionLinefile);

	fprintf ( fp, "Seed                : %d\n", usedseed );
	fprintf ( fp, "Version             : %s\n", Version );
	fclose (fp);

	/* Total number of MCMC iterations */
	Totalite = Burnin + Ite;

	/* read environmental information */
	Temp  = (Environment*) calloc ( Ne, sizeof(Environment));		if(Temp==NULL) alert();
	Photo = (Environment*) calloc ( Ne, sizeof(Environment));		if(Photo==NULL) alert();
	for (env=0; env<Ne; env++)
	{
		Temp[env].v  = (double*) calloc ( Md, sizeof(double));		if(Temp[env].v==NULL) alert();
		Photo[env].v = (double*) calloc ( Md, sizeof(double));		if(Photo[env].v==NULL) alert();
	}

		/* DailyTempfile */
		if ( ( fp = fopen( DailyTempfile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the DailyTempfile\n" );
			return (0);
		}
		for (day=0; day<Md; day++)
			for (env=0; env<Ne; env++)
			{
				TempInt = fscanf (fp, "%lf", Temp[env].v+day);
				if (TempInt == -1){ printf ("Error: the number of elements in the DailyTempfile is lower than Ne*Md (%d * %d)\n", Ne,Md); return(0);}
			}
		TempInt = fscanf (fp, "%lf", &TempDouble);
		if (TempInt != -1) { printf ("Error: the number of elements in the DailyTempfile is larger than Ne*Md (%d * %d)\n", Ne,Md); return(0);}

		/* Photoperiodfile */
		if ( ( fp = fopen( Photoperiodfile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the Photoperiodfile\n" );
			return (0);
		}
		for (day=0; day<Md; day++)
			for (env=0; env<Ne; env++)
			{
				TempInt = fscanf (fp, "%lf", Photo[env].v+day);
				if (TempInt == -1){ printf ("Error: the number of elements in the Photoperiodfile is lower than Ne*Md (%d * %d)\n", Ne,Md); return(0);}
			}

		TempInt = fscanf (fp, "%lf", &TempDouble);
		if (TempInt != -1) { printf ("Error: the number of elements in the Photoperiodfile is larger than Ne*Md (%d * %d)\n", Ne,Md); return(0);}
		fclose (fp);

	/* read line information */
	Line = (Cultivar*) calloc ( Nl, sizeof(Cultivar));		if(Line==NULL) alert();

		if ( ( fp = fopen( Emergencefile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the Emergencefile\n" );
			return (0);
		}
		if ( ( fp2 = fopen( Headingfile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the Headingfile\n" );
			return (0);
		}
		for (line=0; line<Nl; line++)
		{
			Line[line].emergence = (int*) calloc (Ne, sizeof(int));
			Line[line].heading = (int*) calloc (Ne, sizeof(int));
			Line[line].envnum = (int*) calloc (Ne, sizeof(int));
			
			for (env=0; env<Ne; env++)
			{
				TempInt = fscanf (fp, "%d", Line[line].emergence+env);
				if(TempInt == -1) { printf ("Error: the number of elements in the Emergencefile is lower than Nl*Ne (%d * %d)\n", Nl,Ne); return(0);}

				TempInt = fscanf (fp2, "%d", Line[line].heading+env);
				if(TempInt == -1) { printf ("Error: the number of elements in the Headingfile is lower than Nl*Ne (%d * %d)\n", Nl,Ne); return(0);}

				if(Line[line].emergence[env] != Missing) { Line[line].envnum[env] = 1;}
				if((Line[line].emergence[env] == Missing && Line[line].heading[env] != Missing) || (Line[line].emergence[env] != Missing && Line[line].heading[env] == Missing))
				{ printf ("Error: emergencefile and Headingfile are not consistent. Check Missing values\n"); return(0);}
				if(Line[line].emergence[env] >= Line[line].heading[env] && Line[line].heading[env] != Missing)
				{ printf ("Error: emergence date is larger than heading date. line %d environment %d\n", line+1, env+1); return(0);}
			}
		}

		TempInt = fscanf (fp, "%d", &ii);
		if (TempInt != -1) { printf ("Error: the number of elements in the Emergencefile is larger than Nl*Ne (%d * %d)\n", Nl, Ne); return(0);}

		TempInt = fscanf (fp2, "%d", &ii);
		if (TempInt != -1) { printf ("Error: the number of elements in the Headingfile is larger than Nl*Ne (%d * %d)\n", Nl, Ne); return(0);}

		fclose(fp); fclose(fp2);

	/* check the number of days */
	for(env=0; env<Ne; env++)
	{
		for(day=0; day<Md; day++)
			if(Temp[env].v[day]==Missing) break;
		Temp[env].md = day;

		for(day=0; day<Md; day++)
			if(Photo[env].v[day]==Missing) break;
		Photo[env].md = day;

		for(line=0, TempInt = 0; line<Nl; line++)
			if (Line[line].heading[env] > TempInt && Line[line].heading[env] != Missing)
				TempInt = Line[line].heading[env];

		if (Temp[env].md  < TempInt) {printf("Error: the number of days for environment %d in DailyTempfile is fewer than the maximum DH in Observationfile\n",env+1); return(0);}
		if (Photo[env].md < TempInt) {printf("Error: the number of days for environment %d in PhotnoTempfile is fewer than the maximum DH in Observationfile\n",env+1); return(0);}
	}

	/* Transform Temp and Photo */
	ToTb = To - Tb; TcTo = Tc - To; Tratio = TcTo/ToTb;
	PoPb = Po - Pb; PcPo = Pc - Po; Pratio = PcPo/PoPb;
	for (env=0; env<Ne; env++)
	{
		for (day=0; day<Temp[env].md; day++)
			if (Temp[env].v[day] >= Tb && Temp[env].v[day] <= Tc)
			{
				Temp[env].v[day] = (Temp[env].v[day] - Tb)/ToTb * pow((Tc-Temp[env].v[day])/TcTo, Tratio);
			}
			else
			{
				Temp[env].v[day] = 0.0;
			}

		for (day=0; day<Photo[env].md; day++)
			if (Photo[env].v[day] >= Po)
			{
				Photo[env].v[day] = (Photo[env].v[day] - Pb)/PoPb * pow((Pc-Photo[env].v[day])/PcPo, Pratio);
			}
			else
			{
				Photo[env].v[day] = 1;
			}
	}

	/* Read the relationship matrix file */
	if(Assumption==2||Assumption==4)
	{
		Gmatrix =(Matrix*)calloc(Nl, sizeof(Matrix));
		for(line=0; line<Nl; line++)
			Gmatrix[line].e=(double*)calloc(Nl-line,sizeof(double));

		if ( ( fp = fopen( InverseRMfile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the InverseRMfile\n" );
			return (0);
		}
		for(line=0;line<Nl;line++)
		{
			for(ii=0;ii<Nl;ii++)
			{
				if(ii>=line) {row=line; col=ii-line;} else {row=ii; col=line-ii;}
				fscanf(fp, "%lf", Gmatrix[row].e+col);
			}
		}
		fclose(fp);
	}

	/* Read the genotype file */
	if(Assumption==3)
	{
		if ( ( fp = fopen(Genotypefile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the genotype file (%s)\n", Genotypefile );
			return (0);
		}

		X = (Xstruct*) calloc ( P, sizeof (Xstruct) );
		for (locus=0; locus<P; locus++)
		{
			X[locus].covariates = (double*) calloc (Nl, sizeof(double));				if(X[locus].covariates == NULL) alert();
		}

		for (record=0; record<Nl; record++)
			for (locus=0; locus<P; locus++)
			{
				if (fscanf (fp, "%lf", X[locus].covariates+record) == -1) { printf ("Error: number of elements in the genotype file\n"); return(0);}
			}

		if (fscanf (fp, "%lf", &TempDouble) > 0) { printf ("Error: number of elements in the genotype file\n"); return(0);}
		fclose (fp);

		/* only the intercept is considered as the covariate other than marker genotypes */
		Q = (Xstruct*) calloc (1, sizeof(Xstruct));
		Q[0].covariates = (double*) calloc (Nl, sizeof(double));
		for(record=0; record<Nl; record++) Q[0].covariates[record]=1.0;

		/* Store regression coefficeints for g, a, and b */
		Xg = (Xstruct*) calloc (P, sizeof(Xstruct));
		Xa = (Xstruct*) calloc (P, sizeof(Xstruct));
		Xb = (Xstruct*) calloc (P, sizeof(Xstruct));
		Qg = (Xstruct*) calloc (1, sizeof(Xstruct));
		Qa = (Xstruct*) calloc (1, sizeof(Xstruct));
		Qb = (Xstruct*) calloc (1, sizeof(Xstruct));
	}

	/* Partition file for cross-validation across lines */
	if (CVline)
	{
		if ( ( fp = fopen( PartitionLinefile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the PartitionLinefile (%s)\n", PartitionLinefile );
			return (0);
		}

		fscanf (fp, "%d %d", &FoldLine, &MaxntestLine);
		PLine = (Pstruct*) calloc (FoldLine, sizeof(Pstruct));
		for(foldline=0; foldline<FoldLine; foldline++)
		{
			PLine[foldline].obstest = (int*) calloc (MaxntestLine, sizeof(int));
			PLine[foldline].ntest = MaxntestLine;
		}

		for(line=0; line<MaxntestLine; line++)
			for (foldline=0; foldline<FoldLine; foldline++)
			{
				if(fscanf(fp, "%d", &(PLine[foldline].obstest[line]))<1) {printf("Error: observations in the PartitionLinefile are fewer than expected\n"); return(0);}
				if(PLine[foldline].obstest[line] != -9) { PLine[foldline].obstest[line]--;}
			}
		if(fscanf(fp, "%d", &ii) >0) {printf("Error: observations in the PartitionLinefile are more than expected\n"); return(0);}

		for (foldline=0; foldline<FoldLine; foldline++)
			for(line=0; line<MaxntestLine; line++)
				if(PLine[foldline].obstest[line] == -9) {PLine[foldline].ntest = line; break;}

		fclose(fp);
	}
	else
	{
		FoldLine=1;
		PLine = (Pstruct*) calloc (FoldLine, sizeof(Pstruct));
		PLine[0].obstest = (int*) calloc (1, sizeof(int));
		PLine[0].obstest[0] = -9;
	}

	/* Partition file for cross-validation across environments */
	if (CVenv)
	{
		if ( ( fp = fopen( PartitionEnvfile, "r" ) ) == NULL )
		{
	   		printf("Error: cannot open the PartitionEnvfile (%s)\n", PartitionEnvfile );
			return (0);
		}

		fscanf (fp, "%d %d", &FoldEnv, &MaxntestEnv);
		PEnv = (Pstruct*) calloc (FoldEnv, sizeof(Pstruct));
		for(foldenv=0; foldenv<FoldEnv; foldenv++)
		{
			PEnv[foldenv].obstest = (int*) calloc (MaxntestEnv, sizeof(int));
			PEnv[foldenv].ntest = MaxntestEnv;
		}

		for(env=0; env<MaxntestEnv; env++)
			for (foldenv=0; foldenv<FoldEnv; foldenv++)
			{
				if(fscanf(fp, "%d", &(PEnv[foldenv].obstest[env]))<1) {printf("Error: observations in the PartitionEnvfile are fewer than expected\n"); return(0);}
				if(PEnv[foldenv].obstest[env] != -9) { PEnv[foldenv].obstest[env]--;}
			}
		if(fscanf(fp, "%d", &ii) >0) {printf("Error: observations in the PartitionEnvfile are more than expected\n"); return(0);}

		for (foldenv=0; foldenv<FoldEnv; foldenv++)
			for(env=0; env<MaxntestEnv; env++)
				if(PEnv[foldenv].obstest[env] == -9) {PEnv[foldenv].ntest = env; break;}

		fclose(fp);
	}
	else
	{
		FoldEnv=1;
		PEnv = (Pstruct*) calloc (FoldEnv, sizeof(Pstruct));
		PEnv[0].obstest = (int*) calloc (1, sizeof(int));
		PEnv[0].obstest[0] = -9;
	}

	/* Number of MCMC samples */
    Ns = Totalite / Thi;
	Nswb = Ns - Burnin / Thi;

	/* Analysis starts */
	for(foldline=0; foldline<FoldLine; foldline++) /* CV across lines */
	{
		/* Pseudo object */
		LineCv = (Cultivar*) calloc ( Nl, sizeof(Cultivar));
		for (line=0; line<Nl; line++)
		{
			LineCv[line].emergence = (int*) calloc (Ne, sizeof(int));	memcpy(LineCv[line].emergence, Line[line].emergence, Ne*sizeof(int));
			LineCv[line].heading   = (int*) calloc (Ne, sizeof(int));	memcpy(LineCv[line].heading, Line[line].heading, Ne*sizeof(int));
			LineCv[line].envnum    = (int*) calloc (Ne, sizeof(int));	memcpy(LineCv[line].envnum, Line[line].envnum, Ne*sizeof(int));
		}

		/* Response variables */
		if(Assumption==3)
		{
			Y = (Ystruct*) calloc( 3, sizeof(Ystruct));
			for (para=0; para<3; para++)
			{
				Y[para].observations = (double*) calloc (Nl, sizeof(double));
				Y[para].variance = (double*) calloc (Nl, sizeof(double));
			}
		}
		else
		{
			Y = (Ystruct*) calloc(1, sizeof(Ystruct));
		}

		/* Mask information */
		for(line=0, ii=0;line<Nl; line++)
		{
			if(line==PLine[foldline].obstest[ii])
			{
				for(env=0;env<Ne;env++) 
					LineCv[line].envnum[env]=0;

				if(Assumption==3)
					for(para=0; para<3; para++){ Y[para].observations[line]=Masking; Y[para].nmiss ++;}
				ii++;
			}
		}
		if(Assumption==3)
		{
			Nn = Nl - Y[0].nmiss;
			for(para=0; para<3; para++)
			{
				Y[para].use = (int*) calloc (Nn, sizeof(int));	if(Y[para].use==NULL)	alert();
				for(record=0, ii=0; record<Nl; record++)
					if(Y[para].observations[record]!=Masking) {Y[para].use[ii]=record; ii++;}
				/* a, b, and G can be inferred for lines with missing records. But only records without missing are used for regression */ 
			}
		}

		/* Edit genotype data */
		if(Assumption==3)
		{
			/* Calculate sum of squared covariates for non-missing records */
			Q[0].x2 = 0.0;
			for (record=0; record<Nn; record++)
				Q[0].x2 += pow(Q[0].covariates[Y[0].use[record]], 2.0);

			for (locus=0; locus<P; locus++)
			{
				X[locus].x2 = 0.0;
				for (record=0; record<Nn; record++)
					X[locus].x2 += pow(X[locus].covariates[Y[0].use[record]], 2.0);
			}
		}

		/* CV across environments */
		for(foldenv=0; foldenv<FoldEnv; foldenv++)
		{
			/* For MCMC samples */
			Loglike = (double*) calloc (Ns, sizeof(double));	if(Loglike==NULL)	alert();

			/* Pseudo object */
			LineCv2 = (Cultivar*) calloc ( Nl, sizeof(Cultivar));
			for (line=0; line<Nl; line++)
			{
				LineCv2[line].emergence = (int*) calloc (Ne, sizeof(int));	memcpy(LineCv2[line].emergence, LineCv[line].emergence, Ne*sizeof(int));
				LineCv2[line].heading   = (int*) calloc (Ne, sizeof(int));	memcpy(LineCv2[line].heading, LineCv[line].heading, Ne*sizeof(int));
				LineCv2[line].envnum    = (int*) calloc (Ne, sizeof(int));	memcpy(LineCv2[line].envnum, LineCv[line].envnum, Ne*sizeof(int));
				for(env=0, ii=0; env<Ne; env++)
				{
					if(env==PEnv[foldenv].obstest[ii])
					{
						LineCv2[line].envnum[env] = 0; /* masked */
						ii++;
					}
				}
				LineCv2[line].sampledg  =(double*) calloc (Ns, sizeof(double));	if(LineCv2[line].sampledg ==NULL) alert();
				LineCv2[line].sampleda  =(double*) calloc (Ns, sizeof(double));	if(LineCv2[line].sampleda ==NULL) alert();
				LineCv2[line].sampledb  =(double*) calloc (Ns, sizeof(double));	if(LineCv2[line].sampledb ==NULL) alert();
			}

			/* Calculation */
			if(Assumption==1||Assumption==2||Assumption==4)
			{
				MCMCdvr (LineCv2, Temp, Photo, Nl, Ne, Sdforg, Sdfora, Sdforb, Sdforve, SampledSigmag, SampledSigmaa, SampledSigmab, SampledVe, 
						SampledPolySigmag, SampledPolySigmaa, SampledPolySigmab, SampledMug, SampledMua, SampledMub, Loglike, &Acg, &Aca, &Acb, &Acve, Burnin, Ite, Thi, Totalite, 
						Ns, Gmatrix, Assumption, Y, IniMug, IniMua, IniMub, IniSigmag, IniSigmaa, IniSigmab, Logtransform);
			}
			if(Assumption==3)
			{
				MCMCdvrVBEMregression(Nloops, Xg, Xa, Xb, Qg, Qa, Qb,LineCv2, Temp, Photo, Nl, Ne, Sdforg, Sdfora, Sdforb, Sdforve, 
					SampledSigmag, SampledSigmaa, SampledSigmab, SampledVe, SampledMug, SampledMua, SampledMub,Loglike, &Acg, &Aca, &Acb, &Acve, 
					Burnin, Ite, Thi, Totalite, Ns, Gmatrix, Assumption, Methodcode, Algorithm, P, 1, Niterations, Nn, Y, X, Q, H, 
					Xi1g, Xi2g, Xi1a, Xi2a, Xi1b, Xi2b, IniMug, IniMua, IniMub, IniSigmag, IniSigmaa, IniSigmab, Logtransform);
			}

			/* Prediction */
			PredictedDH = (Matrix*) calloc(Nl, sizeof(Matrix));
			for (line=0; line<Nl; line++)
			{
				PredictedDH[line].e = (double*)calloc(Ne*2,sizeof(double));
				PredictMeanSD(PredictedDH+line,LineCv2+line,Temp,Photo,Ne,Burnin,Thi,Nswb,Ns,Logtransform);
			}

			if(Assumption==1||Assumption==2)
				WriteResults12(FoldEnv,foldenv,FoldLine,foldline,LineCv2,SampledSigmag,SampledSigmaa,SampledSigmab,SampledMug,SampledMua,SampledMub,Loglike,SampledVe,Acg,Aca,Acb,Acve, 
					Ns,Nswb,Totalite,Nl,Ne,AnalysisName,FolderName,PredictedDH, Assumption, Logtransform);
			if(Assumption==3)
				WriteResults3(FoldEnv,foldenv,FoldLine,foldline,Nl,Ne,Xg,Xa,Xb,Qg,Qa,Qb,P,1,Methodcode,AnalysisName,FolderName,
					PredictedDH,Algorithm,Y,Acg,Aca,Acb,Acve,Totalite,Nloops,SampledVe,LineCv2,Ns);
			if(Assumption==4)
				WriteResults4(FoldEnv,foldenv,FoldLine,foldline,LineCv2,SampledSigmag,SampledSigmaa,SampledSigmab,Loglike,SampledVe,Acg,Aca,Acb,Acve, 
					Ns,Nswb,Totalite,Nl,Ne,AnalysisName,FolderName,PredictedDH, Assumption, SampledPolySigmag, SampledPolySigmaa, SampledPolySigmab);

			/* free memory */
			for (line=0; line<Nl; line++) {
				free(LineCv2[line].emergence); free(LineCv2[line].heading); free(LineCv2[line].envnum);
				free(LineCv2[line].sampledg); free(LineCv2[line].sampleda); free(LineCv2[line].sampledb);
				free(PredictedDH[line].e);
			}
			free(LineCv2);
			free(Loglike);
			free(PredictedDH);
		}	/*foldenv*/

		/* free memory */
		for (line=0; line<Nl; line++) {
			free(LineCv[line].emergence); free(LineCv[line].heading); free(LineCv[line].envnum);
		}
		free(LineCv);
		if(Assumption==3)
		{
			for(para=0; para<3; para++){free(Y[para].observations); free(Y[para].use);free(Y[para].variance);}
			free(Y);
		}

	}		/*foldline*/

	/* free memory */
	for(line=0; line<Nl; line++) {free(Line[line].emergence); free(Line[line].heading); free(Line[line].envnum);}
	for(env=0; env<Ne; env++) {free(Temp[env].v); free(Photo[env].v);}
	free(Temp); free(Photo); free(Line);

	if(Assumption==1) free(Y);
	if(Assumption==2||Assumption==4)
	{
		for(line=0; line<Nl; line++)
			free(Gmatrix[line].e);
		free(Gmatrix);
		free(Y);
	}
	if(Assumption==3)
	{
		for(locus=0; locus<P; locus++)
			free(X[locus].covariates);
		free(Q[0].covariates);
		free(X);
		free(Q);
		free(Xg); free(Xa); free(Xb); free(Qg); free(Qa); free(Qb);
	}

	for(foldline=0;foldline<FoldLine;foldline++)
		free(PLine[foldline].obstest);
	free(PLine);

	return(0);
}