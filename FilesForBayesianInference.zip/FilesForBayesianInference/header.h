/*----macro function------------------------------------------------------------------------------------------------------------*/
/* Random seed. Time is used when -1 */
#define	seed -1

/* Objects about this algorithm */ 
#define	Version  "02.7"						/* version number */
#define	Maxcolumn	5000					/* maximum number of column */

/* function to determine DVS1 and DVS2 */
#define	DVS1(G) 0.145*G + 0.005*G*G
#define	DVS2(G) 0.345*G + 0.005*G*G

/* value to mask observations */
#define	Masking 9999999

/* lower limit of PickUpOptionSL */
# define Lowerlimitlog -500

/*---- define structures --------------------------------------------------------------------------------------------------------*/
/* Structure for dayily mean temperatrue and photoperiod */
typedef struct 
{
	int		md;							/* maximum number of days at the environment */
	double	*v;							/* daily mean temp. or phetoperiod at the environment */

}	Environment;

/* Structure for cultivar information */
typedef struct
{
	int		*envnum;					/* environment number for the environments where the line was evaluated */
	double	a;							/* alpha */
	double	b;							/* beta */
	double	g;							/* G */
	double	dvs1;						/* DVS1 */
	double	dvs2;						/* DVS2 */
	int		*emergence;					/* emergence date at each environment */
	int		*heading;					/* heading date at each environment */
	double	*sampleda;					/* sampled alpha */
	double	*sampledb;					/* sampled beta */
	double	*sampledg;					/* sampled G */

}	Cultivar;

/* Structure for matrix */
typedef struct
{
	double	*e;		/* elements */

}	Matrix;

typedef struct
{
	int	*e;			/* elements */

}	MatrixInt;

typedef struct {

	int ntest;				/* Number of observations in the test set */
	int *obstest;			/* Observations in the test set */

} Pstruct;

typedef struct {

	double	*covariates;	/* covariates */
	double	x2;				/* sum of squared covariates */
	double	expEffect;		/* expectation of marker effect. When BayesC, this indicates E[B|gamma=1] */
	double	varEffect;		/* variance of marker effect. When BayesC, this indicates V[B|gamma=1] */
	double	exp2Effect;		/* 2nd moment (for wBSR, BayesC, SSVS, and MIX). When BayesC, this indicates E[B^2|gamma=1] */
	double	expGamma;		/* expectation of gamma (for wBSR, SSVS, MIX, and BayesC) */
	double	exp2Gamma;		/* 2nd moment (for wBSR) */
	double	expTau2;		/* expectation of tau (for BL and EBL) */
	double	expInTau2;		/* expectation of the inverse of tau (for BL and EBL) */
	double	expEta2;		/* expectation of eta (for EBL) */
	double	expSigma2;		/* expectation of sigma (for wBSR, BayesC, SSVS, and MIX).*/
	double	S2;				/* parameter of the posterior distribution of marker effect variance (for wBSR, BayesC, SSVS, and MIX) */
	double	a3;				/* shape parameter of the posterior gamma distribution of eta2 (for EBL) */
	double	b3;				/* rate parameter of the posterior gamma distribution of eta2 (for EBL) */

} Xstruct;

typedef struct {

	double	deltaShape;		/* for BL and EBL */
	double	deltaRate;		/* for BL and EBL */
	double	etaShape;		/* for EBL */
	double	etaRate;		/* for EBL */
	double	v;				/* for wBSR, BayesC, SSVS, and MIX */
	double	S2;				/* for wBSR, BayesC, SSVS, and MIX */
	double	Pi;				/* for wBSR, SSVS, MIX, and BayesC */
	double	c;				/* for SSVS and MIX */

} Hstruct;

typedef struct {

	double	*observations;	/* observations (expectations of a, b, and G) */
	double	*variance;		/* variances of a, b, and G */
	double	*stobs;			/* standardized observations */
	double	*expErrors;		/* expected errors */
	int		nmiss;			/* number of missing records */
	int		*use;			/* used records (non-missing record) */
	char	name[101];		/* name of trait */
	double	residualvar;	/* residual variance */

} Ystruct;

/*----For random number generator------------------------------------------------------------------------------------------------*/
int ix, iy, iz;

/*----initialize the random seed (by STRUCTURE)----------------------------------------------------------------------------------*/
int Randomize ( int i )
{
	if ( i == -1 )
		i = (int) time ( NULL );
	srand ( i );
	return ( i );
}

/*----generate a random real number between 0 and 1 (by Ayres1998)---------------------------------------------------------------*/
double WichHill()
{
	ix = (171*ix)%30269;
	iy = (172*iy)%30307;
	iz = (170*iz)%30323;
	return ( fmod ( ( ix/30269.0 ) + ( iy/30307.0) + ( iz/30323.0), 1.0 ) );
}

/*----generate an integer between low and high ----------------------------------------------------------------------------------*/
int RandomInteger ( int low, int high )
{
	int k;

	k = (int) ( WichHill() * (high - low + 1) );
	return (low + k);
}

/*----generate a random real number ---------------------------------------------------------------------------------------------*/
double  RandomReal ( double low, double high)
{
	return ( low + WichHill() * (high - low) );
}

/*----generate a real number from Uniform (0,1) (by STRUCTURE with some modifications)-------------------------------------------*/
double rnd()
{
  double value;

  do
    value = WichHill();
  while ((value==0.0)||(value==1.0));

  return value;
}

/*----generate a real number from Gamma (n, lambda) (by STRUCTURE), E[x] = n/lambda, V[x] = n/lambda^2 --------------------------*/
double RGamma(double n,double lambda)
{
  double ar;
  double w;

	double x = 0.0;
	if ( n < 1 )
	{
		const double E = 2.71828182;
		const double b = ( n + E ) / E;
		double p = 0.0;
		one: 
		p = b * rnd ();
		if ( p > 1 ) goto two;
		x = exp ( log ( p ) / n );
		if ( x > -log ( rnd() ) ) goto one;
		goto three;
		two: 
		x = -log ( ( b - p ) / n );
		if ( ( ( n - 1 ) * log ( x ) ) < log ( rnd() ) ) goto one;
		three:;	
	}
	else 
	{
	    if ( n == 1.0 )
		{                         /* exponential random variable, from Ripley, 1987, P230  */
		    double a = 0.0;
		    double u, u0, ustar;
            ten:
		    u = rnd();
	     	u0 = u;
         	twenty:
		    ustar = rnd();
		    if ( u < ustar) goto thirty;
	    	u = rnd();
		    if ( u < ustar) goto twenty;
	    	a++;
		    goto ten;
        	thirty:
		    return ( a + u0 ) / lambda;
		}
	    else
		{
	    	double static nprev = 0.0;
	     	double static c1 = 0.0;
	    	double static c2 = 0.0;
	    	double static c3 = 0.0;
	    	double static c4 = 0.0;
	    	double static c5 = 0.0;
	    	double u1;
	    	double u2;
	    	if(n != nprev)
			{
		    	c1 = n - 1.0;
		    	ar = 1.0 / c1;
		    	c2 = ar * ( n - 1 / ( 6 * n ) );
		    	c3 = 2 * ar;
		    	c4 = c3 + 2;
		    	if( n > 2.5 ) c5 = 1 / sqrt(n);
			}
		    four:
	       	u1 = rnd();
	       	u2 = rnd();
	       	if ( n <= 2.5 ) goto five;
	       	u1 = u2 + c5 * ( 1 - 1.86 * u1);
	       	if ( ( u1 <= 0 ) || ( u1 >= 1 ) ) goto four;
	       	five:
	       	w = c2 * u2 / u1;
	        if( c3 * u1 + w + 1.0 /w < c4) goto six;
		    if( c3 * log ( u1 ) - log ( w ) + w >= 1) goto four;
	       	six:
	       	x = c1 * w;		
	       	nprev = n;
		}
	}

	return x/lambda;
}

/*----generate a real number from chi square distribution whose degree of freedom = def -----------------------------------------*/
double Rchi( double def )
{
	return ( 2.0 * RGamma ( def / 2.0, 1.0 ) );
}

/*----generate real numbers from N (0,1) ( by STRUCTURE )------------------------------------------------------------------------*/
double snorm()    /*was snorm(void) -- JKP*/
{
static double a[32] = {
    0.0,3.917609E-2,7.841241E-2,0.11777,0.1573107,0.1970991,0.2372021,0.2776904,
    0.3186394,0.36013,0.4022501,0.4450965,0.4887764,0.5334097,0.5791322,
    0.626099,0.6744898,0.7245144,0.7764218,0.8305109,0.8871466,0.9467818,
    1.00999,1.077516,1.150349,1.229859,1.318011,1.417797,1.534121,1.67594,
    1.862732,2.153875
};
static double d[31] = {
    0.0,0.0,0.0,0.0,0.0,0.2636843,0.2425085,0.2255674,0.2116342,0.1999243,
    0.1899108,0.1812252,0.1736014,0.1668419,0.1607967,0.1553497,0.1504094,
    0.1459026,0.14177,0.1379632,0.1344418,0.1311722,0.128126,0.1252791,
    0.1226109,0.1201036,0.1177417,0.1155119,0.1134023,0.1114027,0.1095039
};
static double t[31] = {
    7.673828E-4,2.30687E-3,3.860618E-3,5.438454E-3,7.0507E-3,8.708396E-3,
    1.042357E-2,1.220953E-2,1.408125E-2,1.605579E-2,1.81529E-2,2.039573E-2,
    2.281177E-2,2.543407E-2,2.830296E-2,3.146822E-2,3.499233E-2,3.895483E-2,
    4.345878E-2,4.864035E-2,5.468334E-2,6.184222E-2,7.047983E-2,8.113195E-2,
    9.462444E-2,0.1123001,0.136498,0.1716886,0.2276241,0.330498,0.5847031
};
static double h[31] = {
    3.920617E-2,3.932705E-2,3.951E-2,3.975703E-2,4.007093E-2,4.045533E-2,
    4.091481E-2,4.145507E-2,4.208311E-2,4.280748E-2,4.363863E-2,4.458932E-2,
    4.567523E-2,4.691571E-2,4.833487E-2,4.996298E-2,5.183859E-2,5.401138E-2,
    5.654656E-2,5.95313E-2,6.308489E-2,6.737503E-2,7.264544E-2,7.926471E-2,
    8.781922E-2,9.930398E-2,0.11556,0.1404344,0.1836142,0.2790016,0.7010474
};
static long inr;
static double snorm,u,ss,ustar,anr,w,y,tt;
    u = rnd();   /* was ranf--JKP*/
    ss = 0.0;
    if(u > 0.5) ss = 1.0;
    u += (u-ss);
    u = 32.0*u;
    inr = (long) (u);
    if(inr == 32) inr = 31;
    if(inr == 0) goto S100;
/*
                                START CENTER
*/
    ustar = u-(double)inr;
    anr = *(a+inr-1);
S40:
    if(ustar <= *(t+inr-1)) goto S60;
    w = (ustar-*(t+inr-1))**(h+inr-1);
S50:
/*
                                EXIT   (BOTH CASES)
*/
    y = anr+w;
    snorm = y;
    if(ss == 1.0) snorm = -y;
    return snorm;
S60:
/*
                                CENTER CONTINUED
*/
    u = rnd();                /*was ranf--JKP*/
    w = u*(*(a+inr)-anr);
    tt = (0.5*w+anr)*w;
    goto S80;
S70:
    tt = u;
    ustar = rnd();                /*was ranf--JKP*/
S80:
    if(ustar > tt) goto S50;
    u = rnd();               /*was ranf--JKP*/
    if(ustar >= u) goto S70;
    ustar = rnd();               /*was ranf--JKP*/
    goto S40;
S100:
/*
                                START TAIL
*/
    inr = 6;
    anr = *(a+31);
    goto S120;
S110:
    anr += *(d+inr-1);
    inr += 1;
S120:
    u += u;
    if(u < 1.0) goto S110;
    u -= 1.0;
S140:
    w = u**(d+inr-1);
    tt = (0.5*w+anr)*w;
    goto S160;
S150:
    tt = u;
S160:
    ustar = rnd();               /*was ranf--JKP*/
    if(ustar > tt) goto S50;
    u = rnd();               /*was ranf--JKP*/
    if(ustar >= u) goto S150;
    u = rnd();               /*was ranf--JKP*/
    goto S140;
}

/*----generate real number from N(mu, sd) (by STRUCTURE)-------------------------------------------------------------------------*/
double RNormal(double mu, double sd) 
     /* Returns Normal rv with mean mu, variance sigsq.   
        Uses snorm function of Brown and Lovato.  By JKP*/
{
  return (mu + sd*snorm());
}

/*----alert when allocation of memory is failed-----------------------------------------------------------------------------------*/
void alert ( void )
{
	puts ( "memory allocation failure. try again" );
}

/*----Indicator for symmetric matrix---------------------------------------------------------------------------------------------------*/
/* Position in a symmetric matrix, [a, b], is converted to the corresponding position of the array 
that consists of the upper triangular part of the symmetric matrix*/
/*
int	PositionInSym (int a, int b, int dim)
{
	if (b>=a) { return((int) (a*dim - (a-1)*a/2 + b - a ) ); } else { return ( (int) (b*dim - (b-1)*b/2 + a - b) ); }
}
*/

/*----Multiply vectors. result = A %*% B ------------------------------------------------------------------------------------*/
int MultiplyVectors (const double *A, const double *B, double *result, int dim)
{
	int ii;

	result [0] = 0.0;
	for (ii=0; ii<dim; ii++)
		result [0] += A[ii]*B[ii];

	return(0);
}

/*----perform Gauss-Jordan algorithm 
	from GaussJordan.exe source cord-----------------------------------------------------------------------------------------*/

int GaussJordan (double *A, double *result, int dim)
{
	int		ii,jj, kk, Ne;
	int		Pivotrow, Currentrow, Treatingrow;
	double	Max, temp, invDiag;

	Ne = dim*dim;
	for (ii=0; ii<dim; ii++)
		for (jj=0; jj<dim; jj++)
			if ( ii==jj ) { result [ii*dim + jj] = 1.0; } else { result [ii*dim + jj] = 0.0;}

	for (ii=0; ii<dim; ii++)
	{
		Max = 0.0;
		for (jj=ii; jj<dim; jj++)
		{
			temp = fabs(A[jj*dim + ii]);
			if (temp > Max)
			{
				Max = temp;
				Pivotrow = jj;
			}
		}
		if (Max == 0.0){printf ( "Inversion error\n" ); return(0);}

		Currentrow = ii*dim;
		if ( Pivotrow != ii )
		{
			Pivotrow *= dim;
			for (jj=0; jj<dim; jj++)
			{
				temp = A [Currentrow + jj];
				A [Currentrow + jj] = A [Pivotrow + jj];
				A [Pivotrow + jj] = temp;

				temp = result [Currentrow + jj];
				result [Currentrow + jj] = result [Pivotrow + jj];
				result [Pivotrow + jj] = temp;
			}
		}

		invDiag = 1.0/A[Currentrow + ii];
		for (jj=0; jj<dim; jj++)
		{
			A[Currentrow + jj] *= invDiag;
			result[Currentrow + jj] *= invDiag;
		}

		for (jj=0; jj<dim; jj++)
		{
			if (jj!=ii)
			{
				Treatingrow = jj*dim;
				temp = A[Treatingrow + ii];
				for (kk=0; kk<dim; kk++)
				{
					A[Treatingrow + kk] -= (temp * A[Currentrow + kk]);
					result[Treatingrow + kk] -= (temp * result[Currentrow + kk]);
				}
			}
		}
	}
	return(0);
}

/*----generate a real number from inverse chi square distribution, chi ( v, s2 ) ------------------------------------------------------*/
double Rinchi ( double v, double s2 )
{
	return ( v * s2 / Rchi ( v ) );
}

/*----generate a real number from Beta ( bpa, bpb )-----------------------------------------------------------------------------*/
void RbetaN ( double *a, const double bpa, const double bpb )
{
	double rgm1, rgm2;

	rgm1 = RGamma ( bpa, 1.0 );
	rgm2 = RGamma ( bpb, 1.0 );

	*a = rgm1 / (rgm1 + rgm2);
}

/*----Return 0 with probability a/(a+b) and return 1 with probability b/(a+b) ---------------------------------------------------*/
int PickAnOptionS(const double a, const double b)
{
  int option;
  double random, sum;

  sum = a + b;
  random = RandomReal(0, sum);
  if ( random < a ){ option = 0; } else { option = 1;}

  return option;
}

int PickAnOptionSL(const double a, const double b)
{
  int option;
  double random, sum, max, pa, pb;

  max = a;
  if ( b>max ) max = b;

  pa = a - max; pb = b - max;
  if ( pa < Lowerlimitlog ) { pa = 0.0; } else { pa = exp (pa);} 
  if ( pb < Lowerlimitlog ) { pb = 0.0; } else { pb = exp (pb);}

  /*
  printf ("p0:%f p1:%f ", pa, pb);
  */

  sum = pa + pb;
  random = RandomReal(0, sum);
  if ( random < pa ){ option = 0; } else { option = 1;}

  return option;
}

/* Multinoulli (same as PickAnOptionL in DPART) --------------------------------------------------------------------------------*/
int MultinoulliLog (int total, double *probs)
{
	/* values in probs are overwritten */

	int option;
	double random, sum, max, value;
	double sumsofar = 0.0;

	max = probs [0];				if ( max == 0.0) printf ( "Error in MultinoulliLog\n" );

	for (option=1; option<total; option++ )
	{
		value = probs [option];
		if ( value > max && value != 0.0 )
			max = value;
	}

	sum = 0.0;
	for (option=0; option<total; option++ )
	{
		value = probs [option];
		if ( value != 0.0 ) 
		{
			value -= max;
			if ( value < Lowerlimitlog ) { probs [option] = 0.0; } else { probs [option] = exp ( value );}

		}
		sum += probs [option];
	}

	random = RandomReal(0,sum);
	for (option=0; option<total; option++)
	{
		sumsofar += probs[option];
		if (random <= sumsofar) break;
	}

	return option;
}

int MultinoulliExp (int total, const double *probs)
{
	/* values in probs are not overwritten */

	int option;
	double random, sum = 0.0;
	double sumsofar = 0.0;

	for (option=0; option<total; option++ )
		sum += probs [option];

	random = RandomReal(0,sum);
	for (option=0; option<total; option++)
	{
		sumsofar += probs[option];
		if (random <= sumsofar) break;
	}

	return option;
}

/* ----Mean of the array ---------------------------------------------------------------------------------------------------------*/
double Meanarray ( double *a, int length, double missingrecord )
{
	double sum=0.0;
	int i,j=0;

	for ( i=0; i<length; i++ )
		if (a[i] != missingrecord)
		{
			sum += a[i];
			j ++;
		}

	return ( sum/(double)j );
}

/* ----Variance of the array -----------------------------------------------------------------------------------------------------------*/
double Vararray ( double *a, double mean, int length, double missingrecord )
{
	double sum=0.0;
	int i,j=0;

	for ( i=0; i<length; i++ )
		if (a[i] != missingrecord)
		{
			sum += pow ( ( a[i] - mean ), 2 );
			j++;
		}
	sum /= (double) (j-1);
	return ( sum );
}

/*----Shuffle an array------------------------------------------------------------------------------------------------------------*/
void Shuffle ( int *asl, int arraylength, int timesofshuffle )
{
	int ts, content, target1, target2;

	for ( ts=0; ts<timesofshuffle; ts++ )
	{
		target1 = RandomInteger ( 0, arraylength-1);
		content = asl [target1];
		target2 = RandomInteger ( 0, arraylength-1 );
		asl [target1] = asl [target2];
		asl [target2] = content;
	}
}

/*----Log likelihood (only inside the exponential is evaluated)-------------------------------------------------------------------*/
double Loglikelihood (int ne, int *envnum, int *emergence, int *heading, double giveng, double givena, double givenb, double Ve, 
	Environment *Temp, Environment *Photo, int Logtransform)
{
	double sum, dvs, invg, dvs1, dvs2;
	double g, a, b;
	int env, day, headingdate;

	if(Logtransform){g=exp(giveng); a=exp(givena); b=exp(givenb);}else{g=giveng; a=givena; b=givenb;}
	dvs1=DVS1(g); dvs2=DVS2(g);

	for (env=0, sum=0.0, invg=1.0/g; env<ne; env++)
	{
		if(envnum[env]) /* use the information on environment 'env' */
		{
			headingdate = heading[env]-1;

			for (day=emergence[env]-1, dvs = 0.0; day<=headingdate; day++)/* include the emergence day*/
			{
				if (dvs>=dvs1 && dvs<=dvs2)
				{
					dvs += (pow(Temp[env].v[day], a)*pow(Photo[env].v[day], b));
				}
				else
				{
					dvs += pow(Temp[env].v[day], a);			
				}
			}
			sum += pow((1.0 - dvs*invg), 2.0);
		}
	}
	return(sum * -0.5 / Ve);
}


/*----Prediction----------------------------------------------------------------------------------------------------------------------*/
/* return the day of heading. This corresponds the row number of environment files */
/* env is the environment number (starts with 0) */
int PredictMeanSD (Matrix *Prediction, Cultivar *Line, Environment *Temp, Environment *Photo, int Ne, int Burnin, int Thi, int Nswb, int Ns, int Logtransform)
{
	int		day,sample,env;
	double	dvs1,dvs2,dvs,day2,a,b,g;

	for(env=0; env<Ne; env++)
	{
		for(sample=Burnin/Thi; sample<Ns; sample++)
		{
			if(Logtransform)
			{
				g=exp(Line[0].sampledg[sample]);a=exp(Line[0].sampleda[sample]);b=exp(Line[0].sampledb[sample]);
			}
			else
			{
				g=Line[0].sampledg[sample];a=Line[0].sampleda[sample];b=Line[0].sampledb[sample];
			}

			dvs = 0.0; 	dvs1 = DVS1(g); dvs2 = DVS2(g);
			if(Line[0].envnum[env]){day=Line[0].emergence[env]-2;} else {day=-1;} /* when missing, DH is calculated from the first day */
			do {
				day ++; /* start from the emergence day*/
				if (dvs>=dvs1 && dvs<=dvs2)
				{
					dvs += (pow(Temp[env].v[day], a) * pow(Photo[env].v[day], b));
				}
				else
				{
					dvs += pow(Temp[env].v[day], a);
				}
			} while (dvs<g&&day<=Temp[env].md);

			day2 = (double) day + 1.0;
			Prediction[0].e[2*env] += day2;	/* mean */
			Prediction[0].e[2*env+1] += day2*day2; /* 2nd moment */
		}

		Prediction[0].e[2*env] /= (double) Nswb;
		Prediction[0].e[2*env+1] /= (double) Nswb;
		Prediction[0].e[2*env+1] -= pow(Prediction[0].e[2*env], 2.0);
		Prediction[0].e[2*env+1] = sqrt(Prediction[0].e[2*env+1]);
	}

	return(0);
}

/* not used */
int PredictMeanSDFromRegression (Matrix *Prediction, Cultivar *Line, double MeanG, double SdG, double Meana, double Sda, double Meanb, double Sdb, 
								Environment *Temp, Environment *Photo, int Ne)
{
	/* Log transformation is conducted */
	int day, env, ii, Ns=1000;
	double	dvs1,dvs2,dvs,g,a,b,*Gsamples,*asamples,*bsamples,day2;

	Gsamples=(double*)calloc(Ns, sizeof(double)); asamples=(double*)calloc(Ns, sizeof(double)); bsamples=(double*)calloc(Ns, sizeof(double));
	for(ii=0; ii<Ns; ii++){Gsamples[ii]=exp(RNormal(MeanG, SdG)); asamples[ii]=exp(RNormal(Meana, Sda)); bsamples[ii]=exp(RNormal(Meanb, Sdb));}

	for(ii=0; ii<Ns; ii++)
	{
		g=Gsamples[ii]; a=asamples[ii]; b=bsamples[ii];
		dvs1 = DVS1(g);
		dvs2 = DVS2(g);

		for(env=0; env<Ne; env++)
		{
			dvs = 0.0; 
			if(Line[0].envnum[env]){day=Line[0].emergence[env]-2;} else {day=-1;} /* when missing, DH is calculated from the first day */
			do {
				day ++; /* start from the emergence day*/
				if (dvs>=dvs1 && dvs<=dvs2)
				{
					dvs += (pow(Temp[env].v[day], a) * pow(Photo[env].v[day], b));
				}
				else
				{
					dvs += pow(Temp[env].v[day], a);			
				}
			} while (dvs<g&&day<=Temp[env].md);
			day2 = (double) day + 1.0;
			Prediction[0].e[2*env] += day2;	/* mean */
			Prediction[0].e[2*env+1] += day2*day2; /* 2nd moment */
		}
	}

	for(env=0; env<Ne; env++)
	{
		Prediction[0].e[2*env] /= (double) Ns;
		Prediction[0].e[2*env+1] /= (double) Ns;
		Prediction[0].e[2*env+1] -= pow(Prediction[0].e[2*env], 2.0);
		Prediction[0].e[2*env+1] = sqrt(Prediction[0].e[2*env+1]);
	}

	free(Gsamples); free(asamples); free(bsamples);
	return(0);
}
/*----log density of normal distribution---------------------------------------------------------------------------------------------*/
double	LogDensityNormalKernel (double v, double mu, double var)
{
	return(-0.5 * pow((v - mu), 2.0)/var);
}

double LogDensityGammaKernel (double x, double a, double b)
{
	return((a-1.0)*log(x)-b*x);
}

/*----digamma function-----------------------------------------------------------------------------------------------------------------------*/
/* from http://people.sc.fsu.edu/~jburkardt/cpp_src/asa103/asa103.C. But now cannot be found */
double Digamma ( const double x )
{
  double c = 8.5;
  double d1 = -0.5772156649;
  double r;
  double s = 0.00001;
  double s3 = 0.08333333333;
  double s4 = 0.0083333333333;
  double s5 = 0.003968253968;
  double value;
  double y;

  if ( x <= 0.0 ){printf ( "Error: negative value in Digamma\n" );}
  y = x;
  value = 0.0;
  if ( y <= s )
  {
    value = d1 - 1.0 / y;
    return (value);
  }
   while ( y < c )
  {
    value = value - 1.0 / y;
    y = y + 1.0;
  }
  r = 1.0 / y;
  value = value + log ( y ) - 0.5 * r;
  r = r * r;
  value = value - r * ( s3 - r * ( s4 - r * s5 ) );

  return (value);
}

/*----Calculate the expectations in regression-----------------------------------------------------------------------------------------*/
double PredictYhat (Xstruct *Qe, Xstruct *Qc, int F, Xstruct *Xe, Xstruct *Xc, int P, int i, int Methodcode)
{
	/* i indicates the position in Q and X */

	int locus;
	double	temp=0.0;

	for (locus=0; locus<F; locus++)
		temp += Qc[locus].covariates[i] * Qe[locus].expEffect;

	if (Methodcode==3||Methodcode==4)
	{
		for (locus=0; locus<P; locus++)
			temp += Xc[locus].covariates[i] * Xe[locus].expEffect * Xe[locus].expGamma;
	}
	else
	{
		for (locus=0; locus<P; locus++)
			temp += Xc[locus].covariates[i] * Xe[locus].expEffect;
	}

	return(temp);
}

/*----Generate samples of polygenic effects and polygenic variance. Used when Assumption==4 ----------------------------*/
void SamplePolygenicEffects (double *Error, double *PolySigma, double *Poly, double Sigma, int Nl, Matrix *Gmatrix, double *Aij, double v, double S2, 
	int AfterBurnin, double *SampledPolySigma)
{
	int		line, ii, row, col;
	double	temp, proposal;

	/* Polygenic effects and polygenic effect variance*/
	for(line=0; line<Nl; line++)
	{
		temp = PolySigma[0]/(Gmatrix[line].e[0] + PolySigma[0]/Sigma);

		proposal = RNormal(((Error[line]+Poly[line])/Sigma - (Aij[line] - Poly[line]*Gmatrix[line].e[0])/PolySigma[0])*temp, sqrt(temp));
		Error[line] += (Poly[line]-proposal);
		for(ii=0; ii<Nl; ii++)
		{
			if(ii>=line) {row=line; col=ii-line;} else {row=ii; col=line-ii;}
			Aij[ii]+=(proposal-Poly[line])*Gmatrix[row].e[col];
		}
		Poly[line] = proposal;
	}
	for(line=0, temp=0.0; line<Nl; line++){temp += Poly[line] * Aij[line];}
	if(temp<=0.0) temp=0.001;
	PolySigma[0] = Rinchi((double)Nl+v, (v*S2 + temp)/((double)Nl+v));

	if(AfterBurnin){SampledPolySigma[0] += PolySigma[0]; SampledPolySigma[1] += PolySigma[0]*PolySigma[0];}
}

/* Generate samples of Mu and Sigma -------------------------------------------------------------------------------------------------*/
/* Assumption == 1 or 2 */
void SampleMuSigma (double *Mu, double *SampledMu, double *Sigma, double *SampledSigma, double SumDev2, int Nl, int AfterBurnin, double SumAij, double SumPxA, double v, double S2)
{
	if(SumDev2<=0.0) SumDev2=0.001;
	Sigma[0] = Rinchi((double)Nl+v, (v*S2 + SumDev2)/((double)Nl+v));
	Mu[0] = RNormal(SumPxA/SumAij, sqrt(Sigma[0]/SumAij));

	if(AfterBurnin){SampledSigma[0] += Sigma[0]; SampledSigma[1] += Sigma[0]*Sigma[0]; SampledMu[0] += Mu[0]; SampledMu[1] += Mu[0]*Mu[0];}
}

/* Assumption == 4 */
void SampleMuTau (double *Mu, double *Sigma, double *SampledSigma, int Nl, int AfterBurnin, double *Error, double *Poly, double v, double S2)
{
	int		line;
	double	proposal, temp;

	for(line=0,temp=0.0; line<Nl; line++){temp+=Error[line]+Mu[0];}
	proposal = RNormal(temp/(double)Nl, sqrt(Sigma[0]/(double)Nl));
	for(line=0,temp=0.0; line<Nl; line++){Error[line] += (Mu[0]-proposal); temp+=pow(Error[line],2.0);}
	Mu[0]=proposal;
	Sigma[0]=1.0/RGamma((double)Nl/2.0, temp/2.0);

	if(AfterBurnin){SampledSigma[0] += Sigma[0]; SampledSigma[1] += Sigma[0]*Sigma[0];}
}

/*----Regression---------------------------------------------------------------------------------------------------------------------*/
/* Modification from VIGoR

	Nn and Y[0].use are processed outside this function
	Q[0].x2 and X[0].x2 are processed outside this function
	Lower bound is not calculated.
	LBmonitor and Rmonitor are removed.
	The second moments of response variables (g, a, and b) are added to the update procedure of the residual variance.
	The response variables are scaled using Xi1 and Xi2 as (Y-Xi1)/Xi2.

*/
int	GenomeWideRegression (int Algorithm, int Priortype, int Methodcode, int CondResidual, int P, int F, int N, int Nn, int Niterations, 
	Ystruct *Y, Xstruct *X, Xstruct *Q, Hstruct *H, double *expDelta2, double *Tau0, double Xi1, double Xi2)
{

	/* Count iterations */
	int		ite;

	/* For repeat statement */
	int		record, locus;

	/* Update orders, Timse of shuffling orders, locus to be updated*/
	int		*Order, Times, target;

	/* Temporary objects */
	double	temp, temp2, temp3, temp4, VarTemp; 
		
	/* New values */
	double	prop, prop2;

	/* standardization */
	double	sXi2;

	/* for update of Re2 */
	double	sumVarB;

	/* Product of hyperparameters (when Priortype is 2) */
	double	vS2;

	/* For variable selection (wBSR, SSVS, MIX, and BayesC) */
	double	logPi, log1minusPi;

	/* Probability of gamma (for wBSR, SSVS, MIX, and BayesC) */
	double	ProbInclude, ProbExclude, ProbIncludeConstant, ProbExcludeConstant;

	/* Shape (a) ans rate (b) parameters of posterior gamma distributions (for BL and EBL) */
	double	a1=0.0, b1=0.0, a2=0.0, b2=0.0;

	/* for update of Delta2 */
	double	sumEta2InTau2;

	/* Used when CondResidual == 1 */
	double	sumTau2B2;

	/* Sum of marker effects. Used when BayesC, SSVS, and MIX */
	double	sumGammaB2[2];

	/* Used when MIX and BayesC (sumGamma, sum of gamma), and when Mix (vsS2, product of hyperparameters). */
	double	sumGamma[2], vcS2;

	/* Used when SSVS */
	double	invC, OneMinusInvC, logC;

	/* check convergence */
	double	Check1, Check2, Threshold=1e-9;

	/* Limits of estimates */
	double	Lowesteffect=1.0e-150;
	double	Highestprecision=1.0e+150;


	/* Standardize observations (expectations) and variances */
	Y[0].stobs =(double*) calloc (N, sizeof(double));	if(Y[0].stobs==NULL) alert();
	memcpy (Y[0].stobs, Y[0].observations, sizeof(double) * N);
	for (record=0, sXi2=pow(Xi2,2.0); record<Nn; record++)
	{
		Y[0].stobs[Y[0].use[record]] = (Y[0].observations[Y[0].use[record]] - Xi1)/Xi2;
		Y[0].variance[Y[0].use[record]] /= sXi2;
	}

	/* allocation and initialization */
	for (locus=0; locus<F; locus++)
	{
		Q[locus].expEffect = 0.0;	Q[locus].varEffect = 0.0;	Q[locus].exp2Effect = pow(Q[locus].expEffect,2.0) + Q[locus].varEffect;
	}

	VarTemp=1.0;
	switch (Priortype) {
		case 1: /* BL and EBL */
			Tau0[0] = 100.0/VarTemp;	Tau0[1]=1.0;	expDelta2[0] = 1.0;
			for (locus=0; locus<P; locus++)
			{
				X[locus].expEffect = 0.0;	X[locus].varEffect = 0.0;	X[locus].exp2Effect = pow(X[locus].expEffect,2.0) + X[locus].varEffect;	
				X[locus].expTau2   = (double)P/VarTemp;
				X[locus].expInTau2 = VarTemp/(double)P;
				X[locus].expEta2   = 1.0; /* when expEta2 for all markers are always fixed to 1.0, EBL becomes BL */
			}
			break;
		case 2: /* wBSR, BayesC, SSVS, and MIX */
			Tau0[0] = 100.0/VarTemp;	vS2 = H[0].v * H[0].S2;
			switch(Methodcode){
				case 3: /* wBSR */
					if (H[0].Pi<1.0){logPi = log(H[0].Pi); log1minusPi = log(1.0-H[0].Pi);} /* when BayesB  */
					break;
				case 4: /* BayesC */
					if(H[0].Pi<1.0) /* BayesC */
					{
						logPi = log(H[0].Pi); log1minusPi = log(1.0-H[0].Pi);
						sumGamma[0]=0.0; sumGamma[1]=0.0;
						sumGammaB2[0]=0.0; sumGammaB2[1]=0.0;
					}
					else
					{	/* BRR */
						sumGammaB2[0]=0.0; sumGammaB2[1]=0.0;
					}
					break;
				case 5: /* SSVS */
					logPi = log(H[0].Pi); log1minusPi = log(1.0-H[0].Pi);
					invC = 1.0/H[0].c; OneMinusInvC = 1.0 - invC; logC = log(H[0].c);
					break;
				case 6: /* MIX */
					logPi = log(H[0].Pi); log1minusPi = log(1.0-H[0].Pi);
					sumGamma[0]=0.0; sumGamma[1]=0.0;
					vcS2 = H[0].c * H[0].v * H[0].S2;
					break;
			}
			for (locus=0; locus<P; locus++)
			{
				X[locus].expEffect = 0.0;	X[locus].varEffect = 0.0;	X[locus].exp2Effect = pow(X[locus].expEffect,2.0) + X[locus].varEffect;	
				/* Although we assign initial values for all loci even when BayesC, SSVS, and MIX are used, only the values for the first (and second) locus are used in these cases.*/
				switch(Methodcode){
					case 3: /* wBSR */
						if(H[0].Pi<1.0)
						{ /* Bayes B */
							X[locus].expSigma2 = VarTemp/((double)P*H[0].Pi);	X[locus].S2 = (double)P*H[0].Pi/VarTemp;
							X[locus].expGamma = 0.5;
							X[locus].exp2Gamma = pow(X[locus].expGamma, 2.0) + X[locus].expGamma * (1.0-X[locus].expGamma);
						}
						else
						{ /* Bayes A */
							X[locus].expSigma2 = VarTemp/(double)P;	X[locus].S2 = (double)P/VarTemp;
							X[locus].expGamma = 1.0;
							X[locus].exp2Gamma = 1.0;
						}
						break;
					case 4: /* BayesC */
						if (H[0].Pi<1.0)
						{	/* BayesC */
							X[locus].expSigma2 = VarTemp;	X[locus].S2 = 1.0/VarTemp;
							X[locus].expGamma = 0.5;
							sumGamma[0] += X[locus].expGamma;
							sumGammaB2[0] += X[locus].expGamma * X[locus].exp2Effect;
						}
						else
						{	/* BRR */
							X[locus].expSigma2 = VarTemp;	X[locus].S2 = 1.0/VarTemp;
							X[locus].expGamma = 1.0;
						}
						break;
					case 5: /* SSVS */
						X[locus].expSigma2 = VarTemp;	X[locus].S2 = 1.0/VarTemp;
						X[locus].expGamma = 0.5;
						break;
					case 6: /* MIX */
						X[locus].expSigma2 = VarTemp*0.5;	X[locus].S2 = 2.0/VarTemp;
						X[locus].expGamma = 0.5;
						sumGamma[0] += X[locus].expGamma;
						break;
				}
			}
			break;
	}

	/* Calcualte residual errors */
	Y[0].expErrors = (double*) calloc (N, sizeof(double));	if(Y[0].expErrors==NULL)	alert();
	for(record=0; record<Nn; record++)
	{
		Y[0].expErrors[Y[0].use[record]] = Y[0].stobs[Y[0].use[record]];
		for(locus=0; locus<F; locus++)
			Y[0].expErrors[Y[0].use[record]] -= Q[locus].covariates [Y[0].use[record]] * Q[locus].expEffect;

		if(Methodcode==3||Methodcode==4)
		{
			for(locus=0; locus<P; locus++)
				Y[0].expErrors[Y[0].use[record]] -= X[locus].covariates [Y[0].use[record]] * X[locus].expEffect * X[locus].expGamma;
		}
		else
		{
			for(locus=0; locus<P; locus++)
				Y[0].expErrors[Y[0].use[record]] -= X[locus].covariates [Y[0].use[record]] * X[locus].expEffect;
		}
	}

	/* update order of marker effects */
	Order = (int*) calloc (P, sizeof(int));	if(Order==NULL)	alert();
	for(locus=0; locus<P; locus++) Order[locus] = locus;
//	Shuffle (Order, P, P);
	Times = P / 10;

//	printf ("Start (observation mean: %f SD %f)\n", Mean, Sd);

	/* start optimization */
	for (ite=1; ite<=Niterations; ite++)
	{
		/* To check convergence */
		Check1 = 0.0; Check2 = 0.0;
		
		/* For update of residual variance. Only used when variational Bayesian analysis */
		sumVarB = 0.0;

		/* update of fixed effects */
		for (target=0; target<F; target++)
		{
			for (record=0, temp=0.0; record<Nn; record++)
					temp += Q[target].covariates[Y[0].use[record]] * (Y[0].expErrors[Y[0].use[record]] + Q[target].covariates[Y[0].use[record]] * Q[target].expEffect);

			temp *= Tau0[0];
			temp2 = 1.0/(Q[target].x2 * Tau0[0]);

			prop  = temp * temp2;
			prop2 = prop * prop + temp2;
			for (record=0; record<Nn; record++)
				Y[0].expErrors[Y[0].use[record]] += (Q[target].covariates[Y[0].use[record]] * (Q[target].expEffect - prop));

			sumVarB += (Q[target].x2*temp2);/* used when VB */

			Check1 += pow((prop - Q[target].expEffect), 2.0);
			Check2 += pow(prop, 2.0);
			Q[target].expEffect  = prop;
			Q[target].exp2Effect = prop2;/* used when VB */
			Q[target].varEffect  = temp2;/* used when VB */
		}

		/* update of B */
//		Shuffle (Order, P, Times);
		switch (Priortype) {
			case 1: /* BL and EBL */
				for (locus=0; locus<P; locus++)
				{
					target = Order[locus];

					for(record=0, temp=0.0; record<Nn; record++)
						temp += X[target].covariates[Y[0].use[record]] * (Y[0].expErrors[Y[0].use[record]] + X[target].covariates[Y[0].use[record]] * X[target].expEffect);

					temp *= Tau0[0];
					if(CondResidual) { temp3 = Tau0[0]; } else { temp3 = 1.0;}
					temp2 = 1.0/(X[target].x2 * Tau0[0] + X[target].expTau2 * temp3);

					/* prop: E[B], prop2: E[B^2], temp2: V[B] */
					prop = temp * temp2;	if(fabs(prop)<Lowesteffect) {prop=Lowesteffect;}
					prop2 = prop * prop + temp2;

					for(record=0; record<Nn; record++)
						Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * (X[target].expEffect - prop));
					sumVarB += (X[target].x2*temp2); /* used when VB */

					Check1 += pow((prop - X[target].expEffect), 2.0);
					Check2 += pow(prop, 2.0);

					X[target].expEffect  = prop;
					X[target].exp2Effect = prop2;/* used when VB */
					X[target].varEffect  = temp2;/* used when VB */
				}
				break;

			case 2: /* wBSR, BRR, SSVS, and MIX */
				switch(Methodcode){
					case 4: /* BayesC */
						if(H[0].Pi<1.0)
						{	/* BayesC */
							sumGammaB2[1]=0.0; sumGamma[1]=0.0;
							ProbIncludeConstant=Digamma (0.5*(H[0].v+sumGamma[0])) - 0.5*log(0.5*(sumGammaB2[0]+vS2)) + logPi - log1minusPi;
						}
						else
						{	/* BRR */
							sumGammaB2[0]=0.0;
						}
						break;
					case 5: /* SSVS */
						sumGammaB2[0]=0.0; sumGammaB2[1]=0.0;
						break;
					case 6: /* MIX */
						sumGammaB2[0]=0.0; sumGammaB2[1]=0.0;
						break;
				}
				for (locus=0; locus<P; locus++)
				{
					target = Order[locus];
					if (Methodcode==3||Methodcode==4) /* wBSR and BayesC*/
					{
						for(record=0, temp=0.0; record<Nn; record++)
							temp += X[target].covariates[Y[0].use[record]] * (Y[0].expErrors[Y[0].use[record]] + X[target].covariates[Y[0].use[record]] * X[target].expEffect * X[target].expGamma);
						if(Methodcode==3) temp*=X[target].expGamma;
					}
					else
					{	/* SSVS, and MIX */
						for(record=0, temp=0.0; record<Nn; record++)
							temp += X[target].covariates[Y[0].use[record]] * (Y[0].expErrors[Y[0].use[record]] + X[target].covariates[Y[0].use[record]] * X[target].expEffect);
					}
					temp *= Tau0[0];

					switch (Methodcode) {
						case 3:	/* wBSR */
							switch (Algorithm){
								case 1: /* VB */	temp2 = 1.0/(X[target].x2 * Tau0[0] * X[target].exp2Gamma + 1.0/X[target].S2); break;
								case 2: /* EM */	temp2 = 1.0/(X[target].x2 * Tau0[0] * pow(X[target].expGamma,2.0) + 1.0/X[target].S2); break;
							}
							break;
						case 4: /* BayesC */
							temp2 = 1.0/(X[target].x2 * Tau0[0] + 1.0/X[0].S2);
							break;
						case 5: /* SSVS */
							temp2 = 1.0/(X[target].x2 * Tau0[0] + (X[target].expGamma * OneMinusInvC + invC)/X[0].S2);
							break;
						case 6: /* MIX */
							temp2 = 1.0/(X[target].x2 * Tau0[0] + X[target].expGamma/X[0].S2 + (1.0 - X[target].expGamma)/X[1].S2);
							break;
					}

					/* prop: E[B], prop2: E[B^2], temp2: V[B] */
					prop  = temp * temp2;
					prop2 = pow(prop, 2.0) + temp2;

					switch(Methodcode){
						case 3:	/* wBSR */
							for(record=0; record<Nn; record++)
								Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * X[target].expGamma * (X[target].expEffect - prop));
							if((int)H[0].Pi==1) /* when BayesA */
								sumVarB += (X[target].x2 * temp2); /* used when VB */
							break;
						case 4:	/* BayesC */
							if(H[0].Pi<1.0)
							{	/* BayesC */
								/* update Gamma */
								ProbInclude = 0.5*temp2*temp*temp+0.5*log(temp2);
								ProbInclude += ProbIncludeConstant;
								if(ProbInclude>20.0) ProbInclude=20.0; /* to avoid overflow */
								ProbInclude = exp(ProbInclude);	ProbExclude = 1.0;
								temp3 = ProbInclude/(ProbInclude + ProbExclude);

								/* update residuals */
								for(record=0; record<Nn; record++)
								{
									Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * X[target].expGamma * X[target].expEffect);
									Y[0].expErrors[Y[0].use[record]] -= (X[target].covariates[Y[0].use[record]] * temp3 * prop);
								}
								X[target].expGamma = temp3;
								X[target].exp2Gamma = pow(X[target].expGamma, 2.0) + X[target].expGamma * (1.0 - X[target].expGamma);
								sumVarB += (X[target].x2*X[target].expGamma*(prop2-X[target].expGamma*prop*prop)); /* used when VB */
								switch(Algorithm) {
									case 1: /* VB */	sumGammaB2[1] += prop2 * X[target].expGamma;break; 
									case 2: /* EM */	sumGammaB2[1] += pow(prop, 2.0) * X[target].expGamma;break;
								}
								sumGamma[1] += X[target].expGamma;
								/*---- Note -----------------------------------------------------------------------------------------------------
								  sumGamma[0] and sumGammaB2[0] are not updated here, because these are the posterior parameters of X[0].expSigma. 
								  These values are replaced by sumGamma[1] and sumGammaB2[1] at the update of X[0].expSigma.
								  ---------------------------------------------------------------------------------------------------------------*/
							}
							else
							{	/* BRR */
								for(record=0; record<Nn; record++)
									Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * (X[target].expEffect - prop));
								sumVarB += (X[target].x2 * temp2); /* used when VB */
								switch(Algorithm) { 
									case 1: /* VB */	sumGammaB2[0] += prop2; break;
									case 2: /* EM */	sumGammaB2[0] += pow(prop, 2.0); break;
								}
							}
							break;
						case 5: /* SSVS */
							for(record=0; record<Nn; record++)
								Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * (X[target].expEffect - prop));
							sumVarB += (X[target].x2 * temp2); /* used when VB */
							switch(Algorithm) {
								case 1: /* VB */	temp3 = prop2; break; 
								case 2: /* EM */	temp3 = pow(prop, 2.0); break;
							}
							sumGammaB2[0] += temp3 * X[target].expGamma;
							sumGammaB2[1] += temp3 * (1.0-X[target].expGamma);
							break;
						case 6:	/* MIX (same as SSVS) */
							for(record=0; record<Nn; record++)
								Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * (X[target].expEffect - prop));
							sumVarB += (X[target].x2 * temp2); /* used when VB */
							switch(Algorithm) {
								case 1: /* VB */	temp3 = prop2; break; 
								case 2: /* EM */	temp3 = pow(prop, 2.0); break;
							}
							sumGammaB2[0] += temp3 * X[target].expGamma;
							sumGammaB2[1] += temp3 * (1.0-X[target].expGamma);
							break;
					}
					Check1 += pow((prop - X[target].expEffect), 2.0);
					Check2 += pow(prop, 2.0);
					X[target].expEffect = prop;
					X[target].exp2Effect = prop2;	/* used when VB */
					X[target].varEffect = temp2;	/* used when VB */
				}
				break;
		}

		/* update of Tau2 or Sigma2*/
		switch (Priortype) {
			case 1: /* BL and EBL */
				for(locus=0, sumEta2InTau2=0.0, sumTau2B2=0.0; locus<P; locus++)
				{
					target = Order[locus];

					if (CondResidual) {temp = Tau0[0];} else {temp = 1.0;}
					switch (Algorithm){
						case 1: /* VB */	
							prop = sqrt( expDelta2[0] * X[target].expEta2 / (X[target].exp2Effect * temp) ); 
//							X[target].varTau2 = pow(prop, 3.0)/	(expDelta2[0] * X[target].expEta2) - pow(prop, 2.0);						
							break;
						case 2: /* EM */	prop = sqrt( expDelta2[0] * X[target].expEta2 / temp)/ fabs(X[target].expEffect); break;
					}

					Check1 += pow((prop - X[target].expTau2), 2.0);
					Check2 += pow(prop, 2.0);

					if(CondResidual) 
						switch(Algorithm) {
						case 1: /* VB */ sumTau2B2 += X[target].exp2Effect * prop; break; 
						case 2: /* EM */ sumTau2B2 += pow(X[target].expEffect, 2.0) * prop; break;
						}
						
					X[target].expTau2 = prop;

					prop = 1.0/X[target].expTau2 + 1.0/(expDelta2[0] * X[target].expEta2);
					sumEta2InTau2 += prop * X[target].expEta2;

					X[target].expInTau2 = prop;
				}
				break;

			case 2:	/* wBSR, BRR, SSVS, MIX, and BayesC */
				switch (Methodcode) {
					case 3:	/* wBSR */
						for(locus=0; locus<P; locus++)
						{
							target = Order[locus];
							switch (Algorithm){
								case 1: /* VB */	temp = X[target].exp2Effect + vS2; break;
								case 2: /* EM */	temp = pow(X[target].expEffect, 2.0) + vS2; break;
							}							
							X[target].expSigma2 = temp/(H[0].v - 1.0);
							prop = temp/(H[0].v + 1.0);

							Check1 += pow((prop - X[target].S2), 2.0);
							Check2 += pow(prop, 2.0);

							X[target].S2 = prop;
						}
						break;
					case 4: /* BayesC */
						if(H[0].Pi<1.0)
						{	/* BayesC */
							sumGammaB2[0] = sumGammaB2[1];
							sumGamma[0] = sumGamma[1];
							temp = sumGammaB2[0] + vS2;
							X[0].expSigma2 = temp/(H[0].v + sumGamma[0] - 2.0);
							prop = temp/(H[0].v + sumGamma[0]);
						}
						else
						{	/* BRR */
							temp = sumGammaB2[0] + vS2;
							X[0].expSigma2 = temp/(H[0].v + (double) P - 2.0);
							prop = temp/(H[0].v + (double)P);
						}
						Check1 += pow((prop - X[0].S2), 2.0);
						Check2 += pow(prop, 2.0);
						X[0].S2 = prop;
						break;
					case 5: /* SSVS */
						temp = sumGammaB2[0] + sumGammaB2[1]*invC + vS2;
						X[0].expSigma2 = temp/(H[0].v + (double) P - 2.0);
						prop = temp/(H[0].v + (double)P);

						Check1 += pow((prop - X[0].S2), 2.0);
						Check2 += pow(prop, 2.0);
						X[0].S2 = prop;
						break;
					case 6: /* MIX */;
						temp = sumGammaB2[0] + vS2;
						X[0].expSigma2 = temp/(H[0].v + sumGamma[0] - 2.0);
						prop = temp/(H[0].v + sumGamma[0]);

						Check1 += pow((prop - X[0].S2), 2.0);
						Check2 += pow(prop, 2.0);
						X[0].S2 = prop;

						temp = sumGammaB2[1] + vcS2;
						X[1].expSigma2 = temp/(H[0].v + (double)P - sumGamma[0] - 2.0);
						prop = temp/((double)P - sumGamma[0]);

						Check1 += pow((prop - X[1].S2), 2.0);
						Check2 += pow(prop, 2.0);
						X[1].S2 = prop;
						break;
				}
				break;
		}

		/* update of Delta2 (for BL and EBL)*/
		if (Priortype == 1)
		{
			a2=(double)P + H[0].deltaShape;
			b2=0.5 * sumEta2InTau2 + H[0].deltaRate;
			prop = a2/b2;

			Check1 += pow((prop-expDelta2[0]), 2.0);
			Check2 += pow(prop, 2.0);
			expDelta2[0] = prop;
		}

		/* update of Eta2 (for EBL)*/
		if(Methodcode==2)
		{
//			Shuffle (Order, P, Times);
			for(locus=0; locus<P; locus++)
			{
				target = Order[locus];
				X[target].a3=1.0 + H[0].etaShape;
				X[target].b3=0.5 * expDelta2[0] * X[target].expInTau2 + H[0].etaRate;
				prop = X[target].a3/X[target].b3;

				Check1 += pow((prop - X[target].expEta2), 2.0);
				Check2 += pow(prop, 2.0);
				X[target].expEta2 = prop;
			}
		}

		/* Update of Gamma (for wBSR, SSVS, and MIX) */
		switch (Methodcode){
			case 3: /* wBSR */
				if(H[0].Pi<1.0)
				{ /*when BayesB */
//					Shuffle (Order, P, Times);
					for(locus=0; locus<P; locus++)
					{
						target = Order[locus];

						for (record=0, ProbInclude=0.0, ProbExclude=0.0; record<Nn; record++)
						{
							ProbInclude += pow((Y[0].expErrors [Y[0].use[record]] + (X[target].expGamma - 1.0) * X[target].expEffect * X[target].covariates[Y[0].use[record]]), 2.0);
							ProbExclude += pow((Y[0].expErrors [Y[0].use[record]] + X[target].expGamma * X[target].expEffect * X[target].covariates[Y[0].use[record]]), 2.0);
						}
						/* In this DVR-Regression model, Y[0].variances[record] is added both to ProbInclude and ProbExclude. But bcecause these are cancelled out, these are not added explicitly.*/

						if(Algorithm==1) {ProbInclude += X[target].x2 * X[target].varEffect;} /* when VB */
						ProbInclude *= -0.5 * Tau0[0];	ProbExclude *= -0.5 * Tau0[0];
						ProbInclude += logPi;				ProbExclude += log1minusPi;

						temp = ProbInclude;
						if(temp < ProbExclude) temp = ProbExclude;
						ProbInclude -= temp;	ProbExclude -= temp;

						ProbInclude = exp(ProbInclude);	ProbExclude = exp(ProbExclude);
						prop = ProbInclude/(ProbInclude + ProbExclude);
						prop2 = pow(prop, 2.0) + prop * (1.0 - prop);

						/* update sumVarB and expErrors */
						sumVarB += (X[target].x2 * (prop2*X[target].exp2Effect - pow(prop*X[target].expEffect, 2.0))); /*used when VB */
						for(record=0; record<Nn; record++)
							Y[0].expErrors[Y[0].use[record]] += (X[target].covariates[Y[0].use[record]] * X[target].expEffect * (X[target].expGamma - prop));

						/* for convergence check */
						Check1 += pow((prop - X[target].expGamma), 2.0);
						Check2 += pow(prop, 2.0);

						X[target].expGamma = prop;
						X[target].exp2Gamma = prop2; /* used when variational Bayes */
					}
				}
				break;

			case 5: /* SSVS */
//				Shuffle (Order, P, Times);
				for(locus=0; locus<P; locus++)
				{
					target = Order[locus];
					switch(Algorithm){ 
						case 1: /* VB */ temp4 = X[target].exp2Effect; break;
						case 2: /* EM */ temp4 = pow(X[target].expEffect,2.0); break;
					}

					ProbInclude = - 0.5 * temp4 / X[0].S2 + logPi;
					ProbExclude = - 0.5 * temp4 / X[0].S2 * invC + log1minusPi - 0.5 * logC;

					temp = ProbInclude;
					if(temp < ProbExclude) temp = ProbExclude;
					ProbInclude -= temp;	ProbExclude -= temp;

					ProbInclude = exp(ProbInclude);	ProbExclude = exp(ProbExclude);
					prop = ProbInclude/(ProbInclude + ProbExclude);
					prop2 = pow(prop, 2.0) + prop * (1.0 - prop);

					/* for convergence check */
					Check1 += pow((prop - X[target].expGamma), 2.0);
					Check2 += pow(prop, 2.0);

					X[target].expGamma = prop;	
					X[target].exp2Gamma = prop2;
				}
				break;

			case 6: /* MIX */
//				Shuffle (Order, P, Times);
				ProbIncludeConstant = Digamma (0.5*(H[0].v+sumGamma[0])) - 0.5 * log(0.5*(sumGammaB2[0]+vS2)) + logPi;
				ProbExcludeConstant = Digamma (0.5*(H[0].v+(double)P-sumGamma[0])) - 0.5 * log(0.5*(sumGammaB2[1]+vS2)) + log1minusPi;
				/*---- Note -----------------------------------------------------------------------------------------------------
				  sumGamma[0] and sumGammaB2 are not updated here, because these are the posterior parameters of X[0].expSigma. 
				  sumGamma[0] is replaced by sumGamma[1] after the update of all gamma.
				  sumGammaB2 are updated when marker effects are updated.
				  ---------------------------------------------------------------------------------------------------------------*/
				for(locus=0, sumGamma[1]=0.0; locus<P; locus++)
				{
					target = Order[locus];
					switch(Algorithm){ 
						case 1: /* VB */ temp4 = X[target].exp2Effect; break;
						case 2: /* EM */ temp4 = pow(X[target].expEffect,2.0); break;
					}
					ProbInclude = ProbIncludeConstant - 0.5 * temp4 / X[0].S2;
					ProbExclude = ProbExcludeConstant - 0.5 * temp4 / X[1].S2;

					temp = ProbInclude;
					if(temp < ProbExclude) temp = ProbExclude;
					ProbInclude -= temp;	ProbExclude -= temp;

					ProbInclude = exp(ProbInclude);	ProbExclude = exp(ProbExclude);
					prop = ProbInclude/(ProbInclude + ProbExclude);
					prop2 = pow(prop, 2.0) + prop * (1.0 - prop);

					/* for convergence check */
					Check1 += pow((prop - X[target].expGamma), 2.0);
					Check2 += pow(prop, 2.0);

					X[target].expGamma = prop;	
					X[target].exp2Gamma = prop2;
					sumGamma[1] += X[target].expGamma;
				}
				sumGamma[0] = sumGamma[1];
				break;
		}

		/* update of Re */
		for (record=0, temp=0.0; record<Nn; record++)
		{
			temp += (pow(Y[0].expErrors[Y[0].use[record]], 2.0)+Y[0].variance[Y[0].use[record]]);
		}
		/* "+Y[0].variance[Y[0].use[record]]" was added for this model*/

		switch (Algorithm){
			case 1: /* VB */	
				if (Priortype==1&&CondResidual==1) 
				{
					a1=(double) (P + Nn)*0.5;
					b1=0.5*(temp + sumVarB + sumTau2B2);
				}
				else
				{
					a1=(double)Nn*0.5;
					b1=0.5*(temp + sumVarB);
				}
				prop = a1/b1;
				Tau0[1] = a1 / pow(b1, 2.0);
				break;
			case 2: /* EM */	if (Priortype==1&&CondResidual==1) { prop = (double) (P + Nn - 2)/ (temp + sumTau2B2); }else{ prop = (double)(Nn - 2) / temp;} break;
		}
		Check1 += pow((prop - Tau0[0]), 2.0);
		Check2 += pow(prop, 2.0);
		Tau0[0] = prop;

		temp = Check1/Check2;
//		if (ite%10==0)	printf ( "%d Re2:%f Conv:%f\n", ite, 1.0/Tau0[0], log10(temp));
		if (ite==Niterations||temp<Threshold){ printf ( "Finish at %d (Re2: %f Conv: %f)\n", ite, 1.0/Tau0[0], log10(temp)); break;}
	}	/* ite */

	/* Rescale estimates */
	for (locus=0; locus<F; locus++) { Q[locus].expEffect *= Xi2; Q[locus].varEffect *= sXi2;}
	Q[0].expEffect += Xi1;	/* the first effect is recognized as the overall mean */
	for (locus=0; locus<P; locus++) { X[locus].expEffect *= Xi2; X[locus].varEffect *= sXi2;}
	Tau0[0] /= sXi2;
	Tau0[1] /= (sXi2*sXi2);

	free (Y[0].expErrors); free (Order);; free(Y[0].stobs);

	return(0);
}

/*----MCMC inference for the DVR model---------------------------------------------------------------------------------------------------------*/
int MCMCdvr (Cultivar *Line, Environment *Temp, Environment *Photo, int Nl, int Ne, double Sdforg, double Sdfora, double Sdforb, double Sdforve,
	double *SampledSigmag, double *SampledSigmaa, double *SampledSigmab, double *SampledVe, double *SampledPolySigmag, double *SampledPolySigmaa, double *SampledPolySigmab, 
	double *SampledMug, double *SampledMua, double *SampledMub, double *Loglike,int	*Acg, int *Aca, int *Acb, int *Acve, int Burnin, int Ite, int Thi, int Totalite, int Ns, Matrix *Gmatrix,int Assumption, Ystruct *Y,
	double IniMug, double IniMua, double IniMub, double IniSigmag, double IniSigmaa, double IniSigmab, int Logtransform)
{
/*------------------
Check points
*usage of Nl
------------------*/

	/* order of update of lines */
	int		*Updateorder;

	/* For repeat statement */
	int		mcmc, line, env, ii;

	/* Residual variance */
	double	Ve, NeNl;

	/* parameters for prior distributions fo G, alpha, and beta */
	double	Mug, Mua, Mub, Sigmag, Sigmaa, Sigmab;

	/* For update of Sigmag, Sigmaa, and Sigmab */
	double	SumDevg2, SumDeva2, SumDevb2;

	/* Sampling */
	int		CumNs, DoSampling, AfterBurnin;

	/* MH update */
	double	proposal, MHprob, Veloglikelihood, Sd, Mu, Sigma;
	int		target;

	/* for temporary use */
	double	TempDouble1, TempDouble2;

	/* when the relationship matrix is used */
	double	*GAij, *AAij, *BAij;
	int		row,col;

	/* used when Assumption == 4 */
	double *Polyg, *Polya, *Polyb, *Errorg, *Errora, *Errorb;
	double PolySigmag, PolySigmaa, PolySigmab, v=-2.0, S2=0, Priordensity;

	/* used when Assumption == 1 or 2 */
	double SumAij, SumGxA, SumAxA, SumBxA;

	/*-----For debugging. From here -----------------------------
	FILE	*fp;
	fp = fopen ("log.txt", "w");
	-----to here-----------------------------------------------*/

	/* total number of environments */
	for (line=0, NeNl=0.0; line<Nl; line++)
		for (env=0; env<Ne; env++)
			NeNl += (double) Line[line].envnum[env];

	/* order of update of lines*/
	Updateorder = (int*) calloc (Nl, sizeof(int));
	for (line=0; line<Nl; line++)
		Updateorder [line] = line;

	/* Initialization */
	Mug = IniMug; SampledMug[0] = 0.0; SampledMug[1] = 0.0; /* these objects are not used when Assumption==3 */
	Mua = IniMua; SampledMua[0] = 0.0; SampledMua[1] = 0.0;
	Mub = IniMub; SampledMub[0] = 0.0; SampledMub[1] = 0.0;
	Sigmag = IniSigmag;	SampledSigmag[0] = 0.0; SampledSigmag[1] = 0.0; /* these objects are not used when Assumption==3 */
	Sigmaa = IniSigmaa;	SampledSigmaa[0] = 0.0; SampledSigmaa[1] = 0.0;
	Sigmab = IniSigmab;	SampledSigmab[0] = 0.0; SampledSigmab[1] = 0.0;

	SampledVe[0] = 0.0; SampledVe[1] = 0.0;
	if(Assumption==1||Assumption==2||Assumption==4){Acg[0] = 0; Aca[0] = 0; Acb[0] = 0; Acve[0] = 0;}
	/* When Assumption==3, these objects are initialized outside this function only once */

	if(Assumption==1||Assumption==2)
	{
		for (line=0; line<Nl; line++)
		{
			if(Logtransform)
			{
				Line[line].g = RNormal (Mug, sqrt(Sigmag));
				Line[line].a = RNormal (Mua, sqrt(Sigmaa));
				Line[line].b = RNormal (Mub, sqrt(Sigmab));
			}
			else
			{
				do { Line[line].g = RNormal (Mug, sqrt(Sigmag));} while(Line[line].g<=0.0);
				do { Line[line].a = RNormal (Mua, sqrt(Sigmaa));} while(Line[line].a<=0.0);
				do { Line[line].b = RNormal (Mub, sqrt(Sigmab));} while(Line[line].b<=0.0);
			}
		}
	}
	/* When Assumption==3, initial values of g, a, and b are given outside this function */

	if(Assumption==1)
	{
		SumAij=(double)Nl;
		for(line=0, SumGxA=0.0, SumAxA=0.0, SumBxA=0.0; line<Nl; line++){SumGxA += Line[line].g; SumAxA += Line[line].a; SumBxA += Line[line].b;}
	}
	if(Assumption==2) 
	{
		GAij=(double*)calloc(Nl,sizeof(double)); AAij=(double*)calloc(Nl,sizeof(double)); BAij=(double*)calloc(Nl,sizeof(double));
		for(line=0, SumAij=0.0, SumGxA=0.0, SumAxA=0.0, SumBxA=0.0;line<Nl;line++)
		{
			for(ii=0;ii<Nl;ii++)
			{
				if(ii>=line) {row=line; col=ii-line;} else {row=ii; col=line-ii;}
				TempDouble1 = Gmatrix[row].e[col];
				GAij[line] += (Line[ii].g-Mug) * TempDouble1;
				AAij[line] += (Line[ii].a-Mua) * TempDouble1;
				BAij[line] += (Line[ii].b-Mub) * TempDouble1;
				SumAij += TempDouble1;
				SumGxA += Line[line].g * TempDouble1;
				SumAxA += Line[line].a * TempDouble1;
				SumBxA += Line[line].b * TempDouble1;
			}
		}
	}
	if(Assumption==4)
	{
		Polyg=(double*)calloc(Nl,sizeof(double)); Errorg=(double*)calloc(Nl,sizeof(double));
		Polya=(double*)calloc(Nl,sizeof(double)); Errora=(double*)calloc(Nl,sizeof(double));
		Polyb=(double*)calloc(Nl,sizeof(double)); Errorb=(double*)calloc(Nl,sizeof(double));

		PolySigmag=Sigmag; PolySigmaa=Sigmab; PolySigmab=Sigmab;
		SampledPolySigmag[0] = 0.0; SampledPolySigmag[1] = 0.0;
		SampledPolySigmaa[0] = 0.0; SampledPolySigmaa[1] = 0.0;
		SampledPolySigmab[0] = 0.0; SampledPolySigmab[1] = 0.0;

		for (line=0; line<Nl; line++)
		{
			Polyg[line] = RNormal (0.0, sqrt(PolySigmag));Errorg[line] = RNormal (0.0, sqrt(Sigmag)); Line[line].g = Mug+Polyg[line]+Errorg[line];
			Polya[line] = RNormal (0.0, sqrt(PolySigmaa));Errora[line] = RNormal (0.0, sqrt(Sigmaa)); Line[line].a = Mua+Polya[line]+Errora[line];
			Polyb[line] = RNormal (0.0, sqrt(PolySigmab));Errorb[line] = RNormal (0.0, sqrt(Sigmab)); Line[line].b = Mub+Polyb[line]+Errorb[line];		
		}

		/*-----For debugging. From here -----------------------------
		fp = fopen ("O.fitting.log.gab.txt", "r");
		fscanf(fp,"%*s%*s%*s");
		for(line=0; line<Nl; line++){
			fscanf(fp, "%lf%lf%lf", &(Line[line].g), &(Line[line].a), &(Line[line].b));
			printf("%f %f %f", Line[line].g, Line[line].a, Line[line].b);
		}
		fclose(fp);
		-----to here-----------------------------------------------*/

		/*----For debugging. From here------------------------------
		Sigmag=0.0001; Sigmaa=0.0001; Sigmab=0.0001;
		----to here-----------------------------------------------*/

		GAij=(double*)calloc(Nl,sizeof(double)); AAij=(double*)calloc(Nl,sizeof(double)); BAij=(double*)calloc(Nl,sizeof(double)); /* used for update of polygenic effects*/
		for(line=0;line<Nl;line++)
		{
			for(ii=0;ii<Nl;ii++)
			{
				if(ii>=line) {row=line; col=ii-line;} else {row=ii; col=line-ii;}
				GAij[line] += Polyg[ii] * Gmatrix[row].e[col];
				AAij[line] += Polya[ii] * Gmatrix[row].e[col];
				BAij[line] += Polyb[ii] * Gmatrix[row].e[col];
			}
		}
	}

	Ve = 0.1;
	CumNs = -1;

	printf ("MCMC starts\n");

	for (mcmc=1; mcmc<=Totalite; mcmc++)
	{
		/* Print mcmc */
		if ( mcmc % 100 == 0 ){printf ( "%d\n", mcmc);}

		/* Sample or Not */
		if ( mcmc % Thi == 0) { DoSampling=1; CumNs++;} else { DoSampling=0; }
		if ( DoSampling&&mcmc>Burnin ) { AfterBurnin=1;} else { AfterBurnin=0; }

		/* Shuffle the order of sampling */
		Shuffle (Updateorder, Nl, Nl);

		/* Update of G */
		Sd=Sdforg;
		for(line=0, SumDevg2=0.0; line<Nl; line++)
		{
			target = Updateorder[line];

			MHprob = 0.0;
			proposal = RNormal (Line[target].g, Sd);

			if (!(Logtransform==0&&proposal<0.0))
			{
				MHprob += Loglikelihood (Ne, Line[target].envnum,Line[target].emergence, Line[target].heading, proposal, Line[target].a, Line[target].b, Ve, Temp, Photo, Logtransform);
				MHprob -= Loglikelihood (Ne, Line[target].envnum,Line[target].emergence, Line[target].heading, Line[target].g, Line[target].a, Line[target].b, Ve, Temp, Photo, Logtransform);
				
				switch(Assumption){
				case 1:
					Mu = Mug; Sigma=Sigmag;
					break;
				case 2:
					Mu = -(GAij[target]-(Line[target].g-Mug)*Gmatrix[target].e[0])/Gmatrix[target].e[0]+Mug;
					Sigma = Sigmag/Gmatrix[target].e[0];
					break;
				case 3:
					Mu = Y[0].observations[target]; Sigma=Y[0].residualvar;
					break;
				case 4:			
					for(ii=0,Priordensity=0.0; ii<Nl; ii++)
					{ 
						if(ii>=target) {row=target; col=ii-target;} else {row=ii; col=target-ii;}
						Priordensity += Errorg[ii] * Gmatrix[row].e[col];
					}
					Priordensity -= Errorg[target] * Gmatrix[target].e[0];
					Priordensity /= Gmatrix[target].e[0];
					Mu = Mug + Polyg[target] - Priordensity; 
					Sigma=Sigmag/Gmatrix[target].e[0];
					break;
				}
				MHprob += LogDensityNormalKernel (proposal, Mu, Sigma);
				MHprob -= LogDensityNormalKernel (Line[target].g, Mu, Sigma);

				if (MHprob>log(rnd())) 
				{
					if(Assumption==1) {SumGxA+=(proposal-Line[target].g);}
					if(Assumption==2)
					{
						for(ii=0;ii<Nl;ii++)
						{
							if(ii>=target) {row=target; col=ii-target;} else {row=ii; col=target-ii;}
							GAij[ii]+=(proposal-Line[target].g)*Gmatrix[row].e[col];
							SumGxA+=(proposal-Line[target].g)*Gmatrix[row].e[col];
						}
					}
					if(Assumption==4)
					{
						Errorg[target]=proposal-Mug-Polyg[target];
					}
					Line[target].g = proposal; Acg[0]++; 
				}
			}
			if(Assumption==1){SumDevg2 += pow( (Line[target].g-Mug), 2.0);}
			if(Assumption==2){SumDevg2 += (Line[target].g-Mug)*GAij[target];}
			if(DoSampling) Line[target].sampledg[CumNs] = Line[target].g;
		}

		/*----For debuggin. From here-----------------------------------
		if(SumDevg2<0)
		{
			fprintf(fp,"%d SumDevg2: %f Mug: %f\n", mcmc, SumDevg2, Mug);
		}
		----To here-----------------------------------------------------*/

		/* Update of alpha */
		Sd=Sdfora;
		for(line=0, SumDeva2=0.0; line<Nl; line++)
		{
			target = Updateorder[line];

			MHprob = 0.0;
			proposal = RNormal (Line[target].a, Sd);

			if(!(Logtransform==0&&proposal<0.0))
			{
				MHprob += Loglikelihood (Ne, Line[target].envnum,Line[target].emergence, Line[target].heading, Line[target].g, proposal, Line[target].b, Ve, Temp, Photo, Logtransform);
				MHprob -= Loglikelihood (Ne, Line[target].envnum,Line[target].emergence, Line[target].heading, Line[target].g, Line[target].a, Line[target].b, Ve, Temp, Photo, Logtransform);

				switch(Assumption){
				case 1:
					Mu = Mua; Sigma=Sigmaa;
					break;
				case 2:
					Mu = -(AAij[target]-(Line[target].a-Mua)*Gmatrix[target].e[0])/Gmatrix[target].e[0]+Mua;
					Sigma = Sigmaa/Gmatrix[target].e[0];
					break;
				case 3:
					Mu = Y[1].observations[target]; Sigma=Y[1].residualvar;
					break;
				case 4:
					for(ii=0,Priordensity=0.0; ii<Nl; ii++)
					{ 
						if(ii>=target) {row=target; col=ii-target;} else {row=ii; col=target-ii;}
						Priordensity += Errora[ii] * Gmatrix[row].e[col];
					}
					Priordensity -= Errora[target] * Gmatrix[target].e[0];
					Priordensity /= Gmatrix[target].e[0];
					Mu = Mua + Polya[target] - Priordensity; 
					Sigma = Sigmaa/Gmatrix[target].e[0];
					break;
				}
				MHprob += LogDensityNormalKernel (proposal, Mu, Sigma);
				MHprob -= LogDensityNormalKernel (Line[target].a, Mu, Sigma);

				if (MHprob>log(rnd())) 
				{
					if(Assumption==1) {SumAxA+=(proposal-Line[target].a);}
					if(Assumption==2)
					{
						for(ii=0;ii<Nl;ii++)
						{
							if(ii>=target) {row=target; col=ii-target;} else {row=ii; col=target-ii;}
							AAij[ii]+=(proposal-Line[target].a)*Gmatrix[row].e[col];
							SumAxA+=(proposal-Line[target].a)*Gmatrix[row].e[col];
						}
					}
					if(Assumption==4)
					{
						Errora[target]=proposal-Mua-Polya[target];
					}
					Line[target].a = proposal; Aca[0]++; 
				}
			}
			if(Assumption==1){SumDeva2 += pow((Line[target].a-Mua), 2.0);}
			if(Assumption==2){SumDeva2 += (Line[target].a-Mua)*AAij[target];}
			if(DoSampling) Line[target].sampleda[CumNs] = Line[target].a;
		}

		/* Update of beta */
		Sd=Sdforb;
		for(line=0, SumDevb2=0.0, Veloglikelihood = 0.0; line<Nl; line++)
		{
			target = Updateorder[line];

			MHprob = 0.0;
			proposal = RNormal (Line[target].b, Sd);

			TempDouble2 = Loglikelihood (Ne, Line[target].envnum,Line[target].emergence, Line[target].heading, Line[target].g, Line[target].a, Line[target].b, Ve, Temp, Photo, Logtransform);

			if (!(Logtransform==0&&proposal<0.0))
			{
				TempDouble1 = Loglikelihood (Ne, Line[target].envnum,Line[target].emergence, Line[target].heading, Line[target].g, Line[target].a, proposal, Ve, Temp, Photo, Logtransform);

				MHprob += TempDouble1;
				MHprob -= TempDouble2;
				switch(Assumption){
				case 1:
					Mu = Mub; Sigma=Sigmab;
					break;
				case 2:
					Mu = -(BAij[target]-(Line[target].b-Mub)*Gmatrix[target].e[0])/Gmatrix[target].e[0]+Mub;
					Sigma = Sigmab/Gmatrix[target].e[0];
					break;
				case 3:
					Mu = Y[2].observations[target]; Sigma=Y[2].residualvar;
					break;
				case 4:
					for(ii=0,Priordensity=0.0; ii<Nl; ii++)
					{ 
						if(ii>=target) {row=target; col=ii-target;} else {row=ii; col=target-ii;}
						Priordensity += Errorb[ii] * Gmatrix[row].e[col];
					}
					Priordensity -= Errorb[target] * Gmatrix[target].e[0];
					Priordensity /= Gmatrix[target].e[0];
					Mu = Mub + Polyg[target] - Priordensity; 
					Sigma = Sigmab/Gmatrix[target].e[0];
					break;
				}
				MHprob += LogDensityNormalKernel (proposal, Mu, Sigma);
				MHprob -= LogDensityNormalKernel (Line[target].b, Mu, Sigma);

				if (MHprob>log(rnd())) 
				{
					if(Assumption==1) {SumBxA+=(proposal-Line[target].b);}
					if(Assumption==2)
					{
						for(ii=0;ii<Nl;ii++)
						{
							if(ii>=target) {row=target; col=ii-target;} else {row=ii; col=target-ii;}
							BAij[ii] += (proposal-Line[target].b)*Gmatrix[row].e[col];
							SumBxA+=(proposal-Line[target].b)*Gmatrix[row].e[col];
						}
					}
					if(Assumption==4)
					{
						Errorb[target] = proposal-Mub-Polyb[target];
					}
					Line[target].b = proposal; Acb[0]++;
					Veloglikelihood += TempDouble1;
				}
				else
				{
					Veloglikelihood += TempDouble2;
				}
			}
			else
			{
				Veloglikelihood += TempDouble2;
			}
			if(Assumption==1){SumDevb2 += pow((Line[target].b-Mub), 2.0);}
			if(Assumption==2){SumDevb2 += (Line[target].b-Mub)*BAij[target];}
			if(DoSampling) Line[target].sampledb[CumNs] = Line[target].b;
		}

		/* Update of Ve */
		Sd=Sdforve;
		proposal = RNormal (Ve, Sd);
		TempDouble2 = Veloglikelihood - 0.5 * NeNl * log(Ve);
		if (proposal>0.0)
		{
			TempDouble1 = Veloglikelihood * Ve / proposal - 0.5 * NeNl * log(proposal);

			MHprob = TempDouble1 - TempDouble2;
			MHprob += 1.0/proposal;
			MHprob -= 1.0/Ve;

			if (MHprob>log(rnd()))
			{
				Ve = proposal; Acve[0] ++;
				if (DoSampling) { Loglike [CumNs] = TempDouble1;}
			}
			else
			{
				if (DoSampling) { Loglike [CumNs] = TempDouble2;}
			}
		} 
		else
		{
			if (DoSampling) { Loglike [CumNs] = TempDouble2;}
		}
		if(AfterBurnin){SampledVe[0] += Ve; SampledVe[1] += Ve*Ve;}

		/* Update polygenic effects, and polygenic effect variance */
		if(Assumption==4)
		{
			SamplePolygenicEffects (Errorg, &PolySigmag, Polyg, Sigmag, Nl, Gmatrix, GAij, v, S2, AfterBurnin, SampledPolySigmag);
			SamplePolygenicEffects (Errora, &PolySigmaa, Polya, Sigmaa, Nl, Gmatrix, AAij, v, S2, AfterBurnin, SampledPolySigmaa);
			SamplePolygenicEffects (Errorb, &PolySigmab, Polyb, Sigmab, Nl, Gmatrix, BAij, v, S2, AfterBurnin, SampledPolySigmab);
		}

		/* Update of Mug, Mua, Mub, Sigmag, Sigmaa, and Sigmab */
		if((Assumption==1||Assumption==2)&&Logtransform==1)
		{
			SampleMuSigma (&Mug, SampledMug, &Sigmag, SampledSigmag, SumDevg2, Nl, AfterBurnin, SumAij, SumGxA, v, S2);
			SampleMuSigma (&Mua, SampledMua, &Sigmaa, SampledSigmaa, SumDeva2, Nl, AfterBurnin, SumAij, SumAxA, v, S2);
			SampleMuSigma (&Mub, SampledMub, &Sigmab, SampledSigmab, SumDevb2, Nl, AfterBurnin, SumAij, SumBxA, v, S2);
		}
		if(Assumption==4)
		{
			SampleMuTau (&Mug, &Sigmag, SampledSigmag, Nl, AfterBurnin, Errorg, Polyg, v, S2);
			SampleMuTau (&Mua, &Sigmaa, SampledSigmaa, Nl, AfterBurnin, Errora, Polya, v, S2);
			SampleMuTau (&Mub, &Sigmab, SampledSigmab, Nl, AfterBurnin, Errorb, Polyb, v, S2);
		}

		/*------for debugging. From here----------------------
		if(Assumption==4&&mcmc%10==0)
		{
			printf("%d G: %f %f %f %f %f\n", mcmc,Polyg[0],Polyg[1],Polyg[2],PolySigmag,Sigmag);
			printf("%d a: %f %f %f %f %f\n", mcmc,Polya[0],Polya[1],Polya[2],PolySigmaa,Sigmaa);
			printf("%d b: %f %f %f %f %f\n", mcmc,Polyb[0],Polyb[1],Polyb[2],PolySigmab,Sigmab);
		}
		-------to here------------------------------------*/

		/*------for debugging. From here---------------------
		if((Assumption==1 || Assumption==2)&& mcmc % 10 == 0)
		{
			printf("Sigmag: %f SumDevg2: %f G: %f Mu: %f GAij: %f\n", Sigmag, SumDevg2, Line[0].g, Mug, GAij[0]);
		}
		fprintf(fp,"%d %f %f %f %f\n", mcmc, Sigmag, SumDevg2, Mug, SumGxA);
		------to here-------------------------------------*/

	}	/* mcmc */


	/*------for debugging. From here---------------------
	fclose(fp);
	------to here-------------------------------------*/

	free(Updateorder);
	if(Assumption==2) {free(GAij); free(AAij); free(BAij);}
	if(Assumption==4) {free(GAij); free(AAij); free(BAij); free(Polyg); free(Polya); free(Polyb); free(Errorg); free(Errora); free(Errorb);}

	printf ("MCMC finished\n");

	return(0);
}

/*----Conduct MCMC-VB/EM loops-----------------------------------------------------------------------------------------------------------------------*/
int MCMCdvrVBEMregression (int Nloops, Xstruct *Xg, Xstruct *Xa, Xstruct *Xb, Xstruct *Qg, Xstruct *Qa, Xstruct *Qb,	
	Cultivar *Line, Environment *Temp, Environment *Photo, int Nl, int Ne, double Sdforg, double Sdfora, double Sdforb, double Sdforve,
	double *SampledSigmag, double *SampledSigmaa, double *SampledSigmab, double *SampledVe, double *SampledMug, double *SampledMua, double *SampledMub, 
	double *Loglike,int	*Acg, int *Aca, int *Acb, int *Acve, 
	int Burnin, int Ite, int Thi, int Totalite, int Ns, Matrix *Gmatrix,
	int Assumption, int Methodcode, int Algorithm, int P, int F, int Niterations, int Nn, Ystruct *Y, Xstruct *X, Xstruct *Q, Hstruct *H, 
	double Xi1g, double Xi2g, double Xi1a, double Xi2a, double Xi1b, double Xi2b,
	double IniMug, double IniMua, double IniMub, double IniSigmag, double IniSigmaa, double IniSigmab, int Logtransform)
{
	int	loop;
	int line, locus;
	int Priortype;
	double Check1, Check2, temp, Threshold=1e-6, expDelta2, Tau0[2], DenAcc;
	double pointer1[1], pointer2[1], pointer3[1];

	/*----monitoring-----------
	FILE *Monitor; 
	char File[101]="";
	-------------------------*/

	/* Define Priortype according to Methodcode */
	if(Methodcode<3){Priortype=1;}else{Priortype=2;}

	/* Acceptance rate */
	DenAcc = (double) Totalite*Nl;

	/* Initialization */
	for (line=0; line<Nl; line++)
	{
		Line[line].g = RNormal(IniMug,sqrt(IniSigmag)); Line[line].a = RNormal(IniMua,sqrt(IniSigmaa)); Line[line].b = RNormal(IniMub,sqrt(IniSigmab));
		Y[0].observations[line] = RNormal(IniMug,sqrt(IniSigmag)); Y[1].observations[line] = RNormal(IniMua,sqrt(IniSigmaa)); Y[2].observations[line] = RNormal(IniMub,sqrt(IniSigmab));
//		Line[line].g = IniMug; Line[line].a = IniMua; Line[line].b = IniMub;
//		Y[0].observations[line] = IniMug; Y[1].observations[line] = IniMua; Y[2].observations[line] = IniMub;
	}
	Y[0].residualvar=IniSigmag;
	Y[1].residualvar=IniSigmaa;
	Y[2].residualvar=IniSigmab;
	Acg[0] = 0; Aca[0] = 0; Acb[0] = 0; Acve[0] = 0;

	/* Start MCMC and VB/EM loops */
	for(loop=1; loop<=Nloops; loop++)
	{
		printf ("=================================================================\n");
		printf ("MCMC-VB/EM loop: %d\n", loop);

		if(loop==Nloops)/* At the last loop, the number of iterations of MCMC is Ite */
		{
			MCMCdvr (Line, Temp, Photo, Nl, Ne, Sdfora, Sdforb, Sdforg, Sdforve, SampledSigmag, SampledSigmaa, SampledSigmab, SampledVe, pointer1, pointer2, pointer3,
					SampledMug, SampledMua, SampledMub, Loglike, Acg, Aca, Acb, Acve, Burnin, Ite, Thi, Totalite, Ns, Gmatrix, Assumption, Y, IniMug, IniMua, IniMub, IniSigmag, IniSigmaa, IniSigmab, Logtransform);

			for(line=0; line<Nl; line++)
			{
				Y[0].observations[line] = Meanarray(Line[line].sampledg,Ns,Masking); /* Masking has no meaning */
				Y[1].observations[line] = Meanarray(Line[line].sampleda,Ns,Masking);
				Y[2].observations[line] = Meanarray(Line[line].sampledb,Ns,Masking);
				Y[0].variance[line] = Vararray(Line[line].sampledg,Y[0].observations[line],Ns,Masking);
				Y[1].variance[line] = Vararray(Line[line].sampleda,Y[1].observations[line],Ns,Masking);
				Y[2].variance[line] = Vararray(Line[line].sampledb,Y[2].observations[line],Ns,Masking);
			}

			printf("acceptance rate: g %f a %f b %f Ve %f\n", Acg[0]/(DenAcc*(loop)), Aca[0]/(DenAcc*(loop)), Acb[0]/(DenAcc*(loop)), (double)Acve[0]/(Totalite*(loop)));
		}
		else
		{	/* Before the last loop, the number of iterations of MCMC is Ite/5 */
			MCMCdvr (Line, Temp, Photo, Nl, Ne, Sdfora, Sdforb, Sdforg, Sdforve, SampledSigmag, SampledSigmaa, SampledSigmab, SampledVe, pointer1, pointer2, pointer3,
					SampledMug, SampledMua, SampledMub, Loglike, Acg, Aca, Acb, Acve, Burnin, Ite/5, Thi, Totalite/5, Ns/5, Gmatrix, Assumption, Y, IniMug, IniMua, IniMub, IniSigmag, IniSigmaa, IniSigmab, Logtransform);

			for(line=0; line<Nl; line++)
			{
				Y[0].observations[line] = Meanarray(Line[line].sampledg,Ns/5,Masking); /* Masking has no meaning */
				Y[1].observations[line] = Meanarray(Line[line].sampleda,Ns/5,Masking);
				Y[2].observations[line] = Meanarray(Line[line].sampledb,Ns/5,Masking);
				Y[0].variance[line] = Vararray(Line[line].sampledg,Y[0].observations[line],Ns/5,Masking);
				Y[1].variance[line] = Vararray(Line[line].sampleda,Y[1].observations[line],Ns/5,Masking);
				Y[2].variance[line] = Vararray(Line[line].sampledb,Y[2].observations[line],Ns/5,Masking);
			}

			printf("acceptance rate: g %f a %f b %f Ve %f\n", Acg[0]/(DenAcc*(loop)/5), Aca[0]/(DenAcc*(loop)/5), Acb[0]/(DenAcc*(loop)/5), (double)Acve[0]/(Totalite*(loop)/5));
		}
		/*----monitoring-----------
		sprintf(File, "MCMC.gab.%d.txt", loop);
		Monitor=fopen(File,"w");
		for(line=0;line<Nl;line++){fprintf(Monitor,"%f %f %f\n", Y[0].observations[line], Y[1].observations[line], Y[2].observations[line]);}
		fclose (Monitor);
		-------------------------*/

		Check1=0.0; Check2=0.0; /* Missing (masked) lines are not used in regression. Used lines are defined by Y[].use */
		printf("Regresss G on markers\n");
		GenomeWideRegression (Algorithm, Priortype, Methodcode, 1, P, F, Nl, Nn, Niterations, Y, X, Q, H, &expDelta2, Tau0, Xi1g, Xi2g);
		for(locus=0; locus<P; locus++)
		{
			Check1 += pow((Xg[locus].expEffect-X[locus].expEffect),2.0);
			Xg[locus].expEffect=X[locus].expEffect;
			Check2 += pow(Xg[locus].expEffect,2.0);
			Xg[locus].varEffect=X[locus].varEffect;
			if(Methodcode==3||Methodcode==4)
			{
				Check1 += pow((Xg[locus].expGamma-X[locus].expGamma),2.0);
				Xg[locus].expGamma=X[locus].expGamma;
				Check2 += pow(Xg[locus].expGamma,2.0);
			}
		}
		for(locus=0; locus<F; locus++){ Qg[locus].expEffect=Q[locus].expEffect;Qg[locus].varEffect=Q[locus].varEffect;}

		Y[0].residualvar=1/Tau0[0];

		/*----monitoring-----------
		sprintf(File, "VB.effect.%d.txt", loop);
		Monitor=fopen(File,"w");
		for(locus=0; locus<P; locus++){fprintf(Monitor,"%f ", Xg[locus].expEffect);}
		fprintf(Monitor,"\n");
		-------------------------*/

		printf("Regress alpha on markers\n");
		GenomeWideRegression (Algorithm, Priortype, Methodcode, 1, P, F, Nl, Nn, Niterations, Y+1, X, Q, H, &expDelta2, Tau0, Xi1a, Xi2a);
		for(locus=0; locus<P; locus++)
		{
			Check1 += pow((Xa[locus].expEffect-X[locus].expEffect),2.0);
			Xa[locus].expEffect=X[locus].expEffect;
			Check2 += pow(Xa[locus].expEffect,2.0);
			Xa[locus].varEffect=X[locus].varEffect;
			if(Methodcode==3||Methodcode==4) 
			{
				Check1 += pow((Xa[locus].expGamma-X[locus].expGamma),2.0);
				Xa[locus].expGamma=X[locus].expGamma;
				Check2 += pow(Xa[locus].expGamma,2.0);
			}
		}
		for(locus=0; locus<F; locus++){ Qa[locus].expEffect=Q[locus].expEffect;Qa[locus].varEffect=Q[locus].varEffect;}

		Y[1].residualvar=1/Tau0[0];

		/*----monitoring-----------
		for(locus=0; locus<P; locus++){fprintf(Monitor,"%f ", Xa[locus].expEffect);}
		fprintf(Monitor,"\n");
		-------------------------*/

		printf("Regress beta on markers\n");
		GenomeWideRegression (Algorithm, Priortype, Methodcode, 1, P, F, Nl, Nn, Niterations, Y+2, X, Q, H, &expDelta2, Tau0, Xi1b, Xi2b);
		for(locus=0; locus<P; locus++)
		{
			Check1 += pow((Xb[locus].expEffect-X[locus].expEffect),2.0);
			Xb[locus].expEffect=X[locus].expEffect;
			Check2 += pow(Xb[locus].expEffect,2.0);
			Xb[locus].varEffect=X[locus].varEffect;
			if(Methodcode==3||Methodcode==4)
			{
				Check1 += pow((Xb[locus].expGamma-X[locus].expGamma),2.0);
				Xb[locus].expGamma=X[locus].expGamma;
				Check2 += pow(Xb[locus].expGamma,2.0);
			}
		}
		for(locus=0; locus<F; locus++){ Qb[locus].expEffect=Q[locus].expEffect;Qb[locus].varEffect=Q[locus].varEffect;}

		Y[2].residualvar=1/Tau0[0];

		/*----monitoring-----------
		for(locus=0; locus<P; locus++){fprintf(Monitor,"%f ", Xb[locus].expEffect);}
		fprintf(Monitor,"\n");
		fclose(Monitor);
		-------------------------*/

		if(loop<Nloops)
		{
			for(line=0; line<Nl; line++)
			{
				Y[0].observations[line] = PredictYhat(Qg,Q,F,Xg,X,P,line,Methodcode); /* prior mean of g used for MCMC sampling in the next loop */
				Line[line].g = Y[0].observations[line];	/* initial value of g used for MCMC sampling in the next loop */
				Y[1].observations[line] = PredictYhat(Qa,Q,F,Xa,X,P,line,Methodcode);
				Line[line].a = Y[1].observations[line];
				Y[2].observations[line] = PredictYhat(Qb,Q,F,Xb,X,P,line,Methodcode);
				Line[line].b = Y[2].observations[line];
			}
		}
		/* Note that there will be 2 ways to obtain predicted values for G, a, and b:
		   1) From the posteriors of marker effects by using PredictYhat.
		   2) From the mean of MCMC samples generated by MCMCdvr.
		   In the latter approach, MCMC samples are generated only based on the prior information derived from the posteriors of marker effects.
		   Here the latter is selected.
		   MCMC samples at the last iteration are also output (Line[line].sampledg, a, b)
		*/

		temp=Check1/Check2;
		printf("Convergence: %f\n", log10(temp));
		putchar('\n');
		//if(temp<Threshold){printf ("MCMC-VB/EM loops finished\n"); return(0);}

	} /* loop */

	printf ("Reached the maximum iteration. MCMC-VB/EM loops finished\n");

	return(0);
}

/*----output----------------------------------------------------------------------------------------------------------------------------*/
void WriteResults12 (int FoldEnv, int foldenv, int FoldLine, int foldline, Cultivar *Line, double *SampledSigmag, double *SampledSigmaa, double *SampledSigmab, 
	double *SampledMug, double *SampledMua, double *SampledMub, double *Loglike, double *SampledVe, int Acg, int Aca, int Acb, int Acve, int Ns, int Nswb, int Totalite, int Nl, int Ne,
	char *AnalysisName, char *FolderName, Matrix *PredictedDH, int Assumption, int Logtransform)
{
	FILE	*fp;
	char	File[101]="", CVtype[25]="";
	int		ii,line,env;
	double	TempDouble;

	if(FoldEnv==1)
	{
		if(FoldLine==1){ sprintf(CVtype, "fitting");}else{ sprintf(CVtype, "foldline%d", foldline+1);}
	}
	else
	{
		if(FoldLine==1){sprintf(CVtype,"foldenv%d", foldenv+1);} else {sprintf(CVtype,"foldline%d_foldenv%d",foldline+1,foldenv+1);}
	}

	sprintf (File, "./%s/%s_%s_DH.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(line=0; line<Nl; line++)
	{
		for(env=0; env<Ne; env++)
			fprintf (fp, "%f %f ", PredictedDH[line].e[2*env], PredictedDH[line].e[2*env+1]);
		fprintf (fp, "\n");
	}
	fclose(fp);


	if(Logtransform)
	{
		sprintf (File, "./%s/%s_%s_sampledg.txt", FolderName, AnalysisName, CVtype);
		fp = fopen (File, "w");
		for(ii=0; ii<Ns; ii++)
		{
			for(line=0; line<Nl; line++)
				fprintf (fp, "%f ", exp(Line[line].sampledg[ii]));
			fprintf (fp, "\n");
		}
		fclose(fp);

		sprintf (File, "./%s/%s_%s_sampleda.txt", FolderName, AnalysisName, CVtype);
		fp = fopen (File, "w");
		for(ii=0; ii<Ns; ii++)
		{
			for(line=0; line<Nl; line++)
				fprintf (fp, "%f ", exp(Line[line].sampleda[ii]));
			fprintf (fp, "\n");
		} 
		fclose(fp);

		sprintf (File, "./%s/%s_%s_sampledb.txt", FolderName, AnalysisName, CVtype);
		fp = fopen (File, "w");
		for(ii=0; ii<Ns; ii++)
		{
			for(line=0; line<Nl; line++)
				fprintf (fp, "%f ", exp(Line[line].sampledb[ii]));
			fprintf (fp, "\n");
		}
		fclose(fp);
	}
	else
	{
		sprintf (File, "./%s/%s_%s_sampledg.txt", FolderName, AnalysisName, CVtype);
		fp = fopen (File, "w");
		for(ii=0; ii<Ns; ii++)
		{
			for(line=0; line<Nl; line++)
				fprintf (fp, "%f ", Line[line].sampledg[ii]);
			fprintf (fp, "\n");
		}
		fclose(fp);

		sprintf (File, "./%s/%s_%s_sampleda.txt", FolderName, AnalysisName, CVtype);
		fp = fopen (File, "w");
		for(ii=0; ii<Ns; ii++)
		{
			for(line=0; line<Nl; line++)
				fprintf (fp, "%f ", Line[line].sampleda[ii]);
			fprintf (fp, "\n");
		} 
		fclose(fp);

		sprintf (File, "./%s/%s_%s_sampledb.txt", FolderName, AnalysisName, CVtype);
		fp = fopen (File, "w");
		for(ii=0; ii<Ns; ii++)
		{
			for(line=0; line<Nl; line++)
				fprintf (fp, "%f ", Line[line].sampledb[ii]);
			fprintf (fp, "\n");
		}
		fclose(fp);
	}

	sprintf (File, "./%s/%s_%s_Loglike.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
		fprintf (fp, "%.2f\n", Loglike[ii]);
	fclose(fp);

	sprintf (File, "./%s/%s_%s_others.txt", FolderName, AnalysisName, CVtype);
	TempDouble = (double)(Nl * Totalite);
	fp = fopen (File, "w");
	fprintf (fp, "Acceptance rate\n");
	fprintf (fp, "g:%f a:%f b:%f ve:%f\n", (double)Acg/TempDouble, (double)Aca/TempDouble, (double)Acb/TempDouble, (double)Acve/(double)Totalite);

	fprintf (fp, "\n");
	fprintf (fp, "Mug   : %f (%f)\n", SampledMug[0]/(double)Nswb, sqrt(SampledMug[1]/(double)Nswb-pow(SampledMug[0]/(double)Nswb,2.0)));
	fprintf (fp, "Sigmag: %f (%f)\n", SampledSigmag[0]/(double)Nswb, sqrt(SampledSigmag[1]/(double)Nswb-pow(SampledSigmag[0]/(double)Nswb,2.0)));
	fprintf (fp, "Mua   : %f (%f)\n", SampledMua[0]/(double)Nswb, sqrt(SampledMua[1]/(double)Nswb-pow(SampledMua[0]/(double)Nswb,2.0)));
	fprintf (fp, "Sigmaa: %f (%f)\n", SampledSigmaa[0]/(double)Nswb, sqrt(SampledSigmaa[1]/(double)Nswb-pow(SampledSigmaa[0]/(double)Nswb,2.0)));
	fprintf (fp, "Mub   : %f (%f)\n", SampledMub[0]/(double)Nswb, sqrt(SampledMub[1]/(double)Nswb-pow(SampledMub[0]/(double)Nswb,2.0)));
	fprintf (fp, "Sigmab: %f (%f)\n", SampledSigmab[0]/(double)Nswb, sqrt(SampledSigmab[1]/(double)Nswb-pow(SampledSigmab[0]/(double)Nswb,2.0)));
	fprintf (fp, "Ve    : %f (%f)\n", SampledVe[0]/(double)Nswb, sqrt(SampledVe[1]/(double)Nswb-pow(SampledVe[0]/(double)Nswb,2.0)));
	fclose(fp);

}

void WriteResults3 (int FoldEnv, int foldenv, int FoldLine, int foldline, int Nl, int Ne, 
	Xstruct *Xg, Xstruct *Xa, Xstruct *Xb, Xstruct *Qg, Xstruct *Qa, Xstruct *Qb, int P, int F, int Methodcode,
	char *AnalysisName, char *FolderName, Matrix *PredictedDH, int Algorithm, Ystruct *Y, int Acg, int Aca, int Acb, int Acve, int Totalite, int Nloops, double *SampledVe, 
	Cultivar *Line, int Ns)
{
	/* Log transformation is conducted */
	FILE	*fp;
	char	File[101]="", CVtype[25]="";
	int		line,env,locus,ii;
	double	temp;

	if(FoldEnv==1)
	{
		if(FoldLine==1){ sprintf(CVtype, "fitting");}else{ sprintf(CVtype, "foldline%d", foldline+1);}
	}
	else
	{
		if(FoldLine==1){sprintf(CVtype,"foldenv%d", foldenv+1);} else {sprintf(CVtype,"foldline%d_foldenv%d",foldline+1,foldenv+1);}
	}

	sprintf (File, "./%s/%s_%s_DH.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(line=0; line<Nl; line++)
	{
		for(env=0; env<Ne; env++)
			fprintf (fp, "%f %f ", PredictedDH[line].e[2*env], PredictedDH[line].e[2*env+1]);
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_sampledg.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
	{
		for(line=0; line<Nl; line++)
			fprintf (fp, "%f ", exp(Line[line].sampledg[ii]));
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_sampleda.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
	{
		for(line=0; line<Nl; line++)
			fprintf (fp, "%f ", exp(Line[line].sampleda[ii]));
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_sampledb.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
	{
		for(line=0; line<Nl; line++)
			fprintf (fp, "%f ", exp(Line[line].sampledb[ii]));
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_coefficient.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	fprintf (fp, "g gsd a asd b bsd\n");
	if(Algorithm==1) /* VB */
	{
		for(locus=0; locus<F; locus++)
			fprintf (fp, "%f %f %f %f %f %f\n", Qg[locus].expEffect,sqrt(Qg[locus].varEffect),Qa[locus].expEffect,sqrt(Qa[locus].varEffect),Qb[locus].expEffect,sqrt(Qb[locus].varEffect));
		if(Methodcode==3)
		{
			for(locus=0; locus<P; locus++)
			{
				temp = Xg[locus].expGamma * (1.0-Xg[locus].expGamma) * Xg[locus].varEffect 
					+ Xg[locus].expGamma * (1.0-Xg[locus].expGamma) * pow(Xg[locus].expEffect, 2.0) 
					+ pow(Xg[locus].expGamma,2.0) * Xg[locus].varEffect;
				fprintf (fp, "%f %f ", Xg[locus].expEffect*Xg[locus].expGamma, sqrt(temp));

				temp = Xa[locus].expGamma * (1.0-Xa[locus].expGamma) * Xa[locus].varEffect 
					+ Xa[locus].expGamma * (1.0-Xa[locus].expGamma) * pow(Xa[locus].expEffect, 2.0) 
					+ pow(Xa[locus].expGamma,2.0) * Xa[locus].varEffect;
				fprintf (fp, "%f %f ", Xa[locus].expEffect*Xa[locus].expGamma, sqrt(temp));

				temp = Xb[locus].expGamma * (1.0-Xb[locus].expGamma) * Xb[locus].varEffect 
					+ Xb[locus].expGamma * (1.0-Xb[locus].expGamma) * pow(Xb[locus].expEffect, 2.0) 
					+ pow(Xb[locus].expGamma,2.0) * Xb[locus].varEffect;
				fprintf (fp, "%f %f ", Xb[locus].expEffect*Xb[locus].expGamma, sqrt(temp));
				fprintf(fp,"\n");
			}
		}
		if(Methodcode==4)
		{
			for(locus=0; locus<P; locus++)
			{
				temp = pow(Xg[locus].expEffect,2.0)*Xg[locus].expGamma*(1.0-Xg[locus].expGamma)+Xg[locus].varEffect*Xg[locus].expGamma;
				fprintf (fp, "%f %f ", Xg[locus].expEffect*Xg[locus].expGamma, sqrt(temp));

				temp = pow(Xa[locus].expEffect,2.0)*Xa[locus].expGamma*(1.0-Xa[locus].expGamma)+Xa[locus].varEffect*Xa[locus].expGamma;
				fprintf (fp, "%f %f ", Xa[locus].expEffect*Xa[locus].expGamma, sqrt(temp));

				temp = pow(Xb[locus].expEffect,2.0)*Xb[locus].expGamma*(1.0-Xb[locus].expGamma)+Xb[locus].varEffect*Xb[locus].expGamma;
				fprintf (fp, "%f %f ", Xb[locus].expEffect*Xb[locus].expGamma, sqrt(temp));
				fprintf(fp,"\n");
			}
		}
		if(Methodcode!=3||Methodcode!=4)
			for(locus=0; locus<P; locus++)
				fprintf (fp, "%f %f %f %f %f %f\n", Xg[locus].expEffect,sqrt(Xg[locus].varEffect),Xa[locus].expEffect,sqrt(Xa[locus].varEffect),Xb[locus].expEffect,sqrt(Xb[locus].varEffect));
	}
	else /* EM */
	{
		for(locus=0; locus<F; locus++)
			fprintf (fp, "%f 0 %f 0 %f 0\n", Qg[locus].expEffect, Qa[locus].expEffect, Qb[locus].expEffect);
		if(Methodcode==3||Methodcode==4)
		{
			for(locus=0; locus<P; locus++)
				fprintf (fp, "%f 0 %f 0 %f 0\n", Xg[locus].expEffect*Xg[locus].expGamma, Xa[locus].expEffect*Xa[locus].expGamma, Xb[locus].expEffect*Xb[locus].expGamma);
		}
		else
		{
			for(locus=0; locus<P; locus++)
				fprintf (fp, "%f 0 %f 0 %f 0\n", Xg[locus].expEffect, Xa[locus].expEffect, Xb[locus].expEffect);
		}
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_others.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	fprintf (fp, "Acceptance rate\n");
	fprintf (fp, "g:%f a:%f b:%f ve:%f\n", (double)Acg/(Totalite*Nloops*Nl), (double)Aca/(Totalite*Nloops*Nl), (double)Acb/(Totalite*Nloops*Nl), (double)Acve/(Totalite*Nloops));
	fprintf (fp, "Residualg %f\n", Y[0].residualvar);
	fprintf (fp, "Residuala %f\n", Y[1].residualvar);
	fprintf (fp, "Residualb %f\n", Y[2].residualvar);
	fprintf (fp, "Ve %f (%f)\n", SampledVe[0]/(double)Ns, sqrt(SampledVe[1]/(double)Ns-pow(SampledVe[0]/(double)Ns,2.0)));
	fclose (fp);

}

void WriteResults4 (int FoldEnv, int foldenv, int FoldLine, int foldline, Cultivar *Line, double *SampledSigmag, double *SampledSigmaa, double *SampledSigmab, 
	double *Loglike, double *SampledVe, int Acg, int Aca, int Acb, int Acve, int Ns, int Nswb, int Totalite, int Nl, int Ne,
	char *AnalysisName, char *FolderName, Matrix *PredictedDH, int Assumption, double *SampledPolySigmag, double *SampledPolySigmaa,double *SampledPolySigmab)
{
	/* Log transformation is conducted */
	FILE	*fp;
	char	File[101]="", CVtype[25]="";
	int		ii,line,env;
	double	TempDouble;

	if(FoldEnv==1)
	{
		if(FoldLine==1){ sprintf(CVtype, "fitting");}else{ sprintf(CVtype, "foldline%d", foldline+1);}
	}
	else
	{
		if(FoldLine==1){sprintf(CVtype,"foldenv%d", foldenv+1);} else {sprintf(CVtype,"foldline%d_foldenv%d",foldline+1,foldenv+1);}
	}

	sprintf (File, "./%s/%s_%s_DH.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(line=0; line<Nl; line++)
	{
		for(env=0; env<Ne; env++)
			fprintf (fp, "%f %f ", PredictedDH[line].e[2*env], PredictedDH[line].e[2*env+1]);
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_sampledg.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
	{
		for(line=0; line<Nl; line++)
			fprintf (fp, "%f ", exp(Line[line].sampledg[ii]));
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_sampleda.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
	{
		for(line=0; line<Nl; line++)
			fprintf (fp, "%f ", exp(Line[line].sampleda[ii]));
		fprintf (fp, "\n");
	} 
	fclose(fp);

	sprintf (File, "./%s/%s_%s_sampledb.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
	{
		for(line=0; line<Nl; line++)
			fprintf (fp, "%f ", exp(Line[line].sampledb[ii]));
		fprintf (fp, "\n");
	}
	fclose(fp);

	sprintf (File, "./%s/%s_%s_Loglike.txt", FolderName, AnalysisName, CVtype);
	fp = fopen (File, "w");
	for(ii=0; ii<Ns; ii++)
		fprintf (fp, "%.2f\n", Loglike[ii]);
	fclose(fp);

	sprintf (File, "./%s/%s_%s_others.txt", FolderName, AnalysisName, CVtype);
	TempDouble = (double)(Nl * Totalite);
	fp = fopen (File, "w");
	fprintf (fp, "Acceptance rate\n");
	fprintf (fp, "g:%f a:%f b:%f ve:%f\n", (double)Acg/TempDouble, (double)Aca/TempDouble, (double)Acb/TempDouble, (double)Acve/(double)Totalite);

	fprintf (fp, "\n");
	fprintf (fp, "Sigmag: %f (%f)\n", SampledSigmag[0]/(double)Nswb, sqrt(SampledSigmag[1]/(double)Nswb-pow(SampledSigmag[0]/(double)Nswb,2.0)));
	fprintf (fp, "Sigmaa: %f (%f)\n", SampledSigmaa[0]/(double)Nswb, sqrt(SampledSigmaa[1]/(double)Nswb-pow(SampledSigmaa[0]/(double)Nswb,2.0)));
	fprintf (fp, "Sigmab: %f (%f)\n", SampledSigmab[0]/(double)Nswb, sqrt(SampledSigmab[1]/(double)Nswb-pow(SampledSigmab[0]/(double)Nswb,2.0)));
	fprintf (fp, "Ve    : %f (%f)\n", SampledVe[0]/(double)Nswb, sqrt(SampledVe[1]/(double)Nswb-pow(SampledVe[0]/(double)Nswb,2.0)));
	fprintf (fp, "\n");
	fprintf (fp, "PolySigmag: %f (%f)\n", SampledPolySigmag[0]/(double)Nswb, sqrt(SampledPolySigmag[1]/(double)Nswb-pow(SampledPolySigmag[0]/(double)Nswb,2.0)));
	fprintf (fp, "PolySigmaa: %f (%f)\n", SampledPolySigmaa[0]/(double)Nswb, sqrt(SampledPolySigmaa[1]/(double)Nswb-pow(SampledPolySigmaa[0]/(double)Nswb,2.0)));
	fprintf (fp, "PolySigmab: %f (%f)\n", SampledPolySigmab[0]/(double)Nswb, sqrt(SampledPolySigmab[1]/(double)Nswb-pow(SampledPolySigmab[0]/(double)Nswb,2.0)));
	fclose(fp);

}
